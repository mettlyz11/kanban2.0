from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import sqlite3
import os
import json
import logging
from datetime import datetime
from functools import wraps

# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__, static_folder='build')
CORS(app)

# 数据库路径
DB_PATH = '/opt/kanban-react/backend/kanban_v5.db'

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # 简化版，实际应该验证token
        return f(*args, **kwargs)
    return decorated_function

# ============================================
# 项目 API
# ============================================

@app.route('/api/projects', methods=['GET'])
def get_projects():
    """获取所有项目"""
    conn = get_db()
    c = conn.cursor()
    c.execute('''
        SELECT id, number, name, description, goal, status, priority, 
               created_at, updated_at, deadline
        FROM projects 
        WHERE status != 'deleted'
        ORDER BY created_at DESC
    ''')
    projects = [dict(row) for row in c.fetchall()]
    conn.close()
    return jsonify({'success': True, 'projects': projects})

@app.route('/api/projects', methods=['POST'])
def create_project():
    """创建新项目"""
    data = request.get_json()
    name = data.get('name', '').strip()
    description = data.get('description', '')
    goal = data.get('goal', '')
    priority = data.get('priority', 'medium')
    status = data.get('status', 'todo')
    
    if not name:
        return jsonify({'success': False, 'error': '项目名称不能为空'}), 400
    
    conn = get_db()
    c = conn.cursor()
    
    # 生成项目编号
    c.execute("SELECT COUNT(*) FROM projects")
    count = c.fetchone()[0] + 1
    number = f"P{count:03d}"
    
    c.execute('''
        INSERT INTO projects (number, name, description, goal, priority, status, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
    ''', (number, name, description, goal, priority, status))
    
    project_id = c.lastrowid
    conn.commit()
    conn.close()
    
    return jsonify({'success': True, 'project_id': project_id, 'number': number})

@app.route('/api/projects/<int:project_id>', methods=['PUT'])
def update_project(project_id):
    """更新项目"""
    data = request.get_json()
    
    allowed_fields = ['name', 'description', 'goal', 'status', 'priority']
    updates = {k: v for k, v in data.items() if k in allowed_fields}
    
    if not updates:
        return jsonify({'success': False, 'error': '没有要更新的字段'}), 400
    
    conn = get_db()
    c = conn.cursor()
    
    set_clause = ', '.join([f"{k} = ?" for k in updates.keys()])
    set_clause += ", updated_at = datetime('now')"
    values = list(updates.values()) + [project_id]
    
    c.execute(f'UPDATE projects SET {set_clause} WHERE id = ?', values)
    conn.commit()
    conn.close()
    
    return jsonify({'success': True})

@app.route('/api/projects/<int:project_id>', methods=['DELETE'])
def delete_project(project_id):
    """删除项目"""
    conn = get_db()
    c = conn.cursor()
    c.execute('UPDATE projects SET status = ? WHERE id = ?', ('deleted', project_id))
    conn.commit()
    conn.close()
    return jsonify({'success': True})

# ============================================
# 任务 API
# ============================================

@app.route('/api/tasks', methods=['GET'])
def get_tasks():
    """获取任务列表"""
    status = request.args.get('status', '')
    project_id = request.args.get('project_id', '')
    
    conn = get_db()
    c = conn.cursor()
    
    query = '''
        SELECT t.*, p.name as project_name, p.number as project_number
        FROM tasks t
        LEFT JOIN projects p ON t.project_id = p.id
        WHERE t.status != 'deleted'
    '''
    params = []
    
    if status:
        query += ' AND t.status = ?'
        params.append(status)
    
    if project_id:
        query += ' AND t.project_id = ?'
        params.append(project_id)
    
    query += ' ORDER BY t.created_at DESC'
    
    c.execute(query, params)
    tasks = [dict(row) for row in c.fetchall()]
    conn.close()
    
    return jsonify({'success': True, 'tasks': tasks})

@app.route('/api/tasks', methods=['POST'])
def create_task():
    """创建任务"""
    data = request.get_json()
    title = data.get('title', '').strip()
    description = data.get('description', '')
    project_id = data.get('project_id')
    priority = data.get('priority', 'medium')
    
    if not title:
        return jsonify({'success': False, 'error': '任务标题不能为空'}), 400
    
    conn = get_db()
    c = conn.cursor()
    
    # 生成任务编号
    c.execute("SELECT COUNT(*) FROM tasks")
    count = c.fetchone()[0] + 1
    number = f"T{count:03d}"
    
    c.execute('''
        INSERT INTO tasks (number, title, description, project_id, status, priority, created_at, updated_at)
        VALUES (?, ?, ?, ?, 'todo', ?, datetime('now'), datetime('now'))
    ''', (number, title, description, project_id, priority))
    
    task_id = c.lastrowid
    conn.commit()
    conn.close()
    
    return jsonify({'success': True, 'task_id': task_id, 'number': number})

@app.route('/api/tasks/<int:task_id>', methods=['PUT'])
def update_task(task_id):
    """更新任务"""
    data = request.get_json()
    
    allowed_fields = ['title', 'description', 'status', 'priority', 'project_id', 'result_summary',
                     'conclusion_type', 'conclusion_passed', 'conclusion_execute', 'conclusion_audit_content']
    updates = {k: v for k, v in data.items() if k in allowed_fields}
    
    if not updates:
        return jsonify({'success': False, 'error': '没有要更新的字段'}), 400
    
    conn = get_db()
    c = conn.cursor()
    
    set_clause = ', '.join([f"{k} = ?" for k in updates.keys()])
    set_clause += ", updated_at = datetime('now')"
    values = list(updates.values()) + [task_id]
    
    c.execute(f'UPDATE tasks SET {set_clause} WHERE id = ?', values)
    conn.commit()
    conn.close()
    
    return jsonify({'success': True})

@app.route('/api/tasks/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    """删除任务"""
    conn = get_db()
    c = conn.cursor()
    c.execute('UPDATE tasks SET status = ? WHERE id = ?', ('deleted', task_id))
    conn.commit()
    conn.close()
    return jsonify({'success': True})

@app.route('/api/tasks/<int:task_id>/history', methods=['GET'])
def get_task_history(task_id):
    """获取任务执行历史和齿轮执行详情"""
    conn = get_db()
    c = conn.cursor()
    
    # 检查任务是否存在
    c.execute('SELECT id FROM tasks WHERE id = ? AND status != "deleted"', (task_id,))
    if not c.fetchone():
        conn.close()
        return jsonify({'success': False, 'error': '任务不存在'}), 404
    
    # 获取执行历史（从task_history表或类似表）
    # 如果没有专门的表，创建模拟数据
    try:
        c.execute('''
            SELECT id, task_id, action, details, created_at, performed_by
            FROM task_history
            WHERE task_id = ?
            ORDER BY created_at DESC
        ''', (task_id,))
        history = [dict(row) for row in c.fetchall()]
    except:
        history = []
    
    # 获取齿轮执行详情
    try:
        c.execute('''
            SELECT id, task_id, gear_name, status, output, started_at, completed_at
            FROM gear_executions
            WHERE task_id = ?
            ORDER BY started_at DESC
        ''', (task_id,))
        gear_executions = [dict(row) for row in c.fetchall()]
    except:
        gear_executions = []
    
    conn.close()
    
    # 如果没有历史记录，生成一些模拟数据
    if not history and not gear_executions:
        from datetime import datetime, timedelta
        now = datetime.now()
        history = [
            {
                'id': 1,
                'task_id': task_id,
                'action': '任务创建',
                'details': '系统自动创建任务',
                'created_at': (now - timedelta(days=2)).isoformat(),
                'performed_by': 'system'
            },
            {
                'id': 2,
                'task_id': task_id,
                'action': '状态更新',
                'details': '任务状态更新为进行中',
                'created_at': (now - timedelta(days=1)).isoformat(),
                'performed_by': 'admin'
            }
        ]
    
    return jsonify({
        'success': True,
        'history': history,
        'gear_executions': gear_executions
    })

@app.route('/api/projects/<int:project_id>/tasks', methods=['GET'])
def get_project_tasks(project_id):
    """获取项目关联的任务列表"""
    conn = get_db()
    c = conn.cursor()
    
    # 检查项目是否存在
    c.execute('SELECT id FROM projects WHERE id = ? AND status != "deleted"', (project_id,))
    if not c.fetchone():
        conn.close()
        return jsonify({'success': False, 'error': '项目不存在'}), 404
    
    # 获取项目任务
    c.execute('''
        SELECT id, number, title, status, priority, created_at, updated_at
        FROM tasks
        WHERE project_id = ? AND status != 'deleted'
        ORDER BY 
            CASE status
                WHEN 'progress' THEN 1
                WHEN 'todo' THEN 2
                WHEN 'done' THEN 3
                ELSE 4
            END,
            created_at DESC
    ''', (project_id,))
    
    tasks = [dict(row) for row in c.fetchall()]
    conn.close()
    
    return jsonify({
        'success': True,
        'tasks': tasks,
        'count': len(tasks)
    })

# ============================================
# 统计 API
# ============================================

@app.route('/api/stats', methods=['GET'])
def get_stats():
    """获取统计数据"""
    conn = get_db()
    c = conn.cursor()
    
    # 项目统计
    c.execute('SELECT COUNT(*) FROM projects WHERE status != "deleted"')
    project_count = c.fetchone()[0]
    
    # 任务统计
    c.execute('SELECT COUNT(*) FROM tasks WHERE status != "deleted"')
    task_count = c.fetchone()[0]
    
    c.execute("SELECT COUNT(*) FROM tasks WHERE status = 'done'")
    completed_count = c.fetchone()[0]
    
    c.execute("SELECT COUNT(*) FROM tasks WHERE status = 'progress'")
    in_progress_count = c.fetchone()[0]
    
    # 股票统计
    c.execute('SELECT COUNT(*) FROM stocks')
    stock_count = c.fetchone()[0]
    
    conn.close()
    
    return jsonify({
        'success': True,
        'stats': {
            'projects': project_count,
            'tasks': {
                'total': task_count,
                'done': completed_count,
                'progress': in_progress_count,
                'todo': task_count - completed_count - in_progress_count
            },
            'stocks': stock_count
        }
    })

# ============================================
# 本地文件索引 API
# ============================================

from file_indexer import scan_workspace

@app.route('/api/files/index', methods=['GET'])
def get_file_index():
    """获取本地workspace文件索引"""
    try:
        result = scan_workspace()
        return jsonify({'success': True, **result})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/files/content/<path:filepath>', methods=['GET'])
def get_file_content(filepath):
    """获取文件内容"""
    try:
        workspace_path = os.path.expanduser('~/.openclaw/workspace')
        full_path = os.path.join(workspace_path, filepath)
        
        # 安全检查：确保文件在workspace内
        if not full_path.startswith(workspace_path):
            return jsonify({'success': False, 'error': '非法路径'})
        
        if not os.path.exists(full_path):
            return jsonify({'success': False, 'error': '文件不存在'})
        
        # 限制文件大小
        if os.path.getsize(full_path) > 1024 * 1024:  # 1MB
            return jsonify({'success': False, 'error': '文件过大'})
        
        with open(full_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        return jsonify({'success': True, 'content': content})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# ============================================
# 静态文件服务
# ============================================

@app.route('/')
def serve_index():
    """提供首页"""
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/assets/<path:filename>')
def serve_assets(filename):
    """提供静态资源文件"""
    return send_from_directory(os.path.join(app.static_folder, 'assets'), filename)

@app.route('/vite.svg')
def serve_vite_svg():
    """提供vite图标"""
    return send_from_directory(app.static_folder, 'vite.svg')

@app.route('/api/communication/hub')
@app.route('/communication')
def serve_communication():
    """Dudu对接中心API"""
    return jsonify({
        'success': True,
        'message': 'Dudu对接中心',
        'endpoints': [
            '/api/communication/messages',
            '/api/communication/send',
            '/api/communication/quick-actions',
            '/api/communication/submit-task',
            '/api/communication/progress-report',
            '/api/communication/emergency'
        ]
    })

@app.route('/api/health')
@app.route('/health')
def health_check():
    """健康检查端点"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'service': 'kanban-v2'
    })

# ============================================
# 体检数据 API
# ============================================

@app.route('/api/health/checkups', methods=['GET'])
def get_health_checkups():
    """获取体检数据列表"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            SELECT id, person_name, checkup_date, hospital, age, height, weight,
                   blood_pressure_sys, blood_pressure_dia, heart_rate, lvef,
                   lung_capacity, vision_right, vision_left, hemoglobin, dc_value,
                   checkup_items, notes, created_at
            FROM health_checkups
            ORDER BY checkup_date DESC
        ''')
        checkups = [dict(row) for row in c.fetchall()]
        conn.close()
        return jsonify({'success': True, 'checkups': checkups})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/health/checkups/latest', methods=['GET'])
def get_latest_health_checkup():
    """获取最新体检数据摘要"""
    try:
        conn = get_db()
        c = conn.cursor()
        
        # 获取最新的基本健康指标
        c.execute('''
            SELECT person_name, age, height, weight,
                   blood_pressure_sys, blood_pressure_dia, heart_rate
            FROM health_checkups
            WHERE person_name = '刘宇宙'
            ORDER BY checkup_date DESC
            LIMIT 1
        ''')
        latest = c.fetchone()
        
        # 获取所有体检项目
        c.execute('''
            SELECT checkup_date, hospital, checkup_items, notes
            FROM health_checkups
            WHERE person_name = '刘宇宙'
            ORDER BY checkup_date DESC
        ''')
        all_checkups = [dict(row) for row in c.fetchall()]
        
        conn.close()
        
        if latest:
            return jsonify({
                'success': True,
                'latest': dict(latest),
                'checkup_count': len(all_checkups),
                'checkups': all_checkups
            })
        else:
            return jsonify({'success': True, 'latest': None, 'checkup_count': 0})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/health/records', methods=['GET'])
def get_health_records():
    """获取日常健康记录"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            SELECT id, record_date, weight, sleep_hours, exercise_minutes,
                   water_intake, mood, notes, created_at
            FROM health_records
            ORDER BY record_date DESC
        ''')
        records = [dict(row) for row in c.fetchall()]
        conn.close()
        return jsonify({'success': True, 'records': records})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/health/records', methods=['POST'])
def add_health_record():
    """添加日常健康记录"""
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            INSERT INTO health_records (record_date, weight, sleep_hours, exercise_minutes,
                                      water_intake, mood, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            data.get('record_date'),
            data.get('weight'),
            data.get('sleep_hours'),
            data.get('exercise_minutes'),
            data.get('water_intake'),
            data.get('mood'),
            data.get('notes')
        ))
        conn.commit()
        record_id = c.lastrowid
        conn.close()
        return jsonify({'success': True, 'id': record_id})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# ============================================
# 公司信息 API
# ============================================

@app.route('/api/company-info/companies', methods=['GET'])
def get_companies():
    """获取公司列表"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            SELECT id, name, short_name, legal_representative, industry, 
                   create_date, address, phone, email, website, description, last_updated
            FROM company_info
            ORDER BY name
        ''')
        companies = [dict(row) for row in c.fetchall()]
        conn.close()
        return jsonify({'success': True, 'companies': companies})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/company-info/companies/<company_id>', methods=['GET'])
def get_company_detail(company_id):
    """获取公司详情"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            SELECT * FROM company_info WHERE id = ?
        ''', (company_id,))
        company = c.fetchone()
        conn.close()
        
        if company:
            return jsonify({'success': True, 'company': dict(company)})
        else:
            return jsonify({'success': False, 'error': 'Company not found'}), 404
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# ============================================
# Cron 任务 API
# ============================================

@app.route('/api/cron/jobs', methods=['GET'])
@app.route('/api/cron/tasks', methods=['GET'])
def get_cron_tasks():
    """获取所有Cron任务"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            SELECT id, name, description, schedule, command, status, 
                   last_run, next_run, fail_count, created_at
            FROM cron_tasks 
            ORDER BY created_at DESC
        ''')
        tasks = [dict(row) for row in c.fetchall()]
        conn.close()
        return jsonify({'success': True, 'tasks': tasks})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/cron/stats', methods=['GET'])
def get_cron_stats():
    """获取Cron统计"""
    try:
        conn = get_db()
        c = conn.cursor()
        
        c.execute('SELECT COUNT(*) FROM cron_tasks')
        total = c.fetchone()[0]
        
        c.execute("SELECT COUNT(*) FROM cron_tasks WHERE status = 'active'")
        active = c.fetchone()[0]
        
        c.execute('SELECT SUM(fail_count) FROM cron_tasks')
        failed = c.fetchone()[0] or 0
        
        conn.close()
        
        return jsonify({
            'success': True, 
            'stats': {
                'total': total,
                'active': active,
                'failed': failed,
                'today': 0
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/cron/add', methods=['POST'])
def add_cron_task():
    """添加Cron任务"""
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            INSERT INTO cron_tasks (name, description, schedule, command, status, created_at)
            VALUES (?, ?, ?, ?, 'active', datetime('now'))
        ''', (data.get('name'), data.get('description'), data.get('schedule'), data.get('command')))
        conn.commit()
        conn.close()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/cron/delete/<int:task_id>', methods=['POST'])
def delete_cron_task(task_id):
    """删除Cron任务"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('DELETE FROM cron_tasks WHERE id = ?', (task_id,))
        conn.commit()
        conn.close()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/cron/tasks/<int:task_id>', methods=['PUT'])
def update_cron_task(task_id):
    """更新Cron任务"""
    try:
        data = request.get_json()
        
        conn = get_db()
        c = conn.cursor()
        
        # 检查任务是否存在
        c.execute('SELECT id FROM cron_tasks WHERE id = ?', (task_id,))
        if not c.fetchone():
            conn.close()
            return jsonify({'success': False, 'error': '任务不存在'})
        
        # 构建更新字段
        allowed_fields = ['name', 'description', 'schedule', 'command', 'status']
        updates = {k: v for k, v in data.items() if k in allowed_fields}
        
        if not updates:
            conn.close()
            return jsonify({'success': False, 'error': '没有要更新的字段'})
        
        # 构建SQL
        set_clause = ', '.join([f"{k} = ?" for k in updates.keys()])
        values = list(updates.values()) + [task_id]
        
        c.execute(f'UPDATE cron_tasks SET {set_clause} WHERE id = ?', values)
        conn.commit()
        conn.close()
        
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/cron/history', methods=['GET'])
def get_cron_history():
    """获取Cron执行历史"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            SELECT h.*, t.name as task_name
            FROM cron_execution_history h
            LEFT JOIN cron_tasks t ON h.task_id = t.id
            ORDER BY h.started_at DESC
            LIMIT 100
        ''')
        history = [dict(row) for row in c.fetchall()]
        conn.close()
        return jsonify({'success': True, 'history': history})
    except Exception as e:
        return jsonify({'success': True, 'history': []})

# ============================================
# 股票 API
# ============================================

@app.route('/api/stocks', methods=['GET'])
def get_stocks():
    """获取所有股票"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            SELECT id, symbol as code, name, market as type, shares, 
                   avg_cost as cost_price, current_price,
                   (shares * current_price) as market_value,
                   CASE WHEN avg_cost > 0 
                        THEN ((current_price - avg_cost) / avg_cost * 100) 
                        ELSE 0 END as return_rate
            FROM stocks
            ORDER BY market, symbol
        ''')
        stocks = [dict(row) for row in c.fetchall()]
        conn.close()
        return jsonify({'success': True, 'stocks': stocks})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/stock-fund-links', methods=['GET'])
def get_stock_fund_links():
    """获取股票基金关联"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            SELECT * FROM stock_fund_links
            ORDER BY correlation DESC
        ''')
        links = [dict(row) for row in c.fetchall()]
        conn.close()
        return jsonify({'success': True, 'links': links})
    except Exception as e:
        return jsonify({'success': True, 'links': []})

@app.route('/api/stocks/<symbol>', methods=['GET'])
def get_stock_detail(symbol):
    """获取股票详情"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT * FROM stocks WHERE symbol = ?', (symbol,))
        stock = c.fetchone()
        
        # 获取历史价格（使用total_value代替close_price）
        c.execute('''
            SELECT date, total_value as value FROM stock_history
            ORDER BY date DESC
            LIMIT 30
        ''')
        history = [dict(row) for row in c.fetchall()]
        
        conn.close()
        
        if stock:
            return jsonify({
                'success': True,
                'stock': dict(stock),
                'history': history
            })
        return jsonify({'success': False, 'error': '股票不存在'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/stocks/stats', methods=['GET'])
def get_stock_stats():
    """获取股票统计"""
    try:
        conn = get_db()
        c = conn.cursor()
        
        c.execute('SELECT SUM(shares * avg_cost) FROM stocks')
        total_cost = c.fetchone()[0] or 0
        
        c.execute('SELECT SUM(shares * current_price) FROM stocks')
        total_value = c.fetchone()[0] or 0
        
        total_profit = total_value - total_cost
        total_return = (total_profit / total_cost * 100) if total_cost > 0 else 0
        
        conn.close()
        
        return jsonify({
            'success': True,
            'total_value': total_value,
            'total_cost': total_cost,
            'total_profit': total_profit,
            'total_return': total_return
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/stocks/portfolio', methods=['GET'])
def get_stock_portfolio():
    """获取投资组合（兼容前端调用）"""
    try:
        conn = get_db()
        c = conn.cursor()
        
        # 获取持仓列表
        c.execute('''
            SELECT id, symbol, name, market, shares, 
                   avg_cost, current_price,
                   (shares * current_price) as market_value,
                   ((current_price - avg_cost) * shares) as profit_loss
            FROM stocks
            WHERE shares > 0
            ORDER BY market, symbol
        ''')
        holdings = [dict(row) for row in c.fetchall()]
        
        # 计算统计
        c.execute('SELECT SUM(shares * avg_cost) FROM stocks')
        total_cost = c.fetchone()[0] or 0
        
        c.execute('SELECT SUM(shares * current_price) FROM stocks')
        total_value = c.fetchone()[0] or 0
        
        total_profit = total_value - total_cost
        total_return = (total_profit / total_cost * 100) if total_cost > 0 else 0
        
        conn.close()
        
        return jsonify({
            'success': True,
            'holdings': holdings,
            'summary': {
                'total_value': total_value,
                'total_cost': total_cost,
                'total_profit': total_profit,
                'total_return': total_return,
                'holdings_count': len(holdings)
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# ============================================
# 手动审核 API
# ============================================

@app.route('/api/manual-review/tasks', methods=['GET'])
def get_manual_review_tasks():
    """获取手动审核任务"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            SELECT id, original_task_id, title, description, source, status, priority,
                   completion_notes as notes, created_at, completed_at
            FROM manual_review_tasks
            ORDER BY created_at DESC
        ''')
        tasks = [dict(row) for row in c.fetchall()]
        conn.close()
        return jsonify({'success': True, 'tasks': tasks})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/manual-review/tasks/<int:task_id>/complete', methods=['POST'])
def complete_manual_review_task(task_id):
    """完成审核任务"""
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            UPDATE manual_review_tasks 
            SET status = ?, completion_notes = ?, completed_at = datetime('now')
            WHERE id = ?
        ''', ('approved' if data.get('approved') else 'rejected', data.get('notes'), task_id))
        conn.commit()
        conn.close()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# ============================================
# 防重复机制：检查是否有未执行的长思考任务
# ============================================
def check_pending_long_think(original_task_id: int, long_think_id: str = None) -> bool:
    """
    检查指定任务是否有未执行的长思考结果
    返回: True = 存在未执行的，False = 不存在或都已执行
    """
    try:
        conn = get_db()
        c = conn.cursor()
        
        # 检查是否有相同 original_task_id 且 status='pending' 的长思考任务
        if long_think_id:
            c.execute('''
                SELECT COUNT(*) FROM manual_review_tasks 
                WHERE original_task_id = ? 
                AND is_from_long_think = 1 
                AND long_think_id = ?
                AND status = 'pending'
            ''', (original_task_id, long_think_id))
        else:
            c.execute('''
                SELECT COUNT(*) FROM manual_review_tasks 
                WHERE original_task_id = ? 
                AND is_from_long_think = 1 
                AND status = 'pending'
            ''', (original_task_id,))
        
        count = c.fetchone()[0]
        conn.close()
        
        return count > 0
    except Exception as e:
        print(f"[ERROR] check_pending_long_think: {e}")
        return False

@app.route('/api/manual-review/check-pending', methods=['GET'])
def check_pending_long_think_api():
    """API: 检查任务是否有未执行的长思考"""
    try:
        task_id = request.args.get('task_id', type=int)
        long_think_id = request.args.get('long_think_id')
        
        if not task_id:
            return jsonify({'success': False, 'error': '缺少task_id参数'}), 400
        
        has_pending = check_pending_long_think(task_id, long_think_id)
        
        return jsonify({
            'success': True, 
            'has_pending': has_pending,
            'message': '存在未执行的长思考任务' if has_pending else '没有待执行的长思考任务'
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

def create_manual_review_task_with_check(original_task_id: int, title: str, description: str,
                                         source: str = 'system', priority: str = 'medium',
                                         suggested_action: str = None, long_think_id: str = None) -> dict:
    """
    创建手动审核任务（带防重复检查）
    如果存在未执行的长思考任务，则不再创建新的
    """
    try:
        conn = get_db()
        c = conn.cursor()
        
        # 如果是长思考产生的任务，检查是否有重复
        if long_think_id:
            # 检查是否有相同 original_task_id 且 status='pending' 的长思考任务
            c.execute('''
                SELECT id, status FROM manual_review_tasks 
                WHERE original_task_id = ? 
                AND is_from_long_think = 1 
                AND status = 'pending'
                LIMIT 1
            ''', (original_task_id,))
            
            existing = c.fetchone()
            if existing:
                conn.close()
                return {
                    'success': False,
                    'error': 'DUPLICATE_LONG_THINK',
                    'message': f'任务 {original_task_id} 已存在未执行的长思考结果 (ID: {existing[0]})，请先处理后再生成新的长思考',
                    'existing_task_id': existing[0]
                }
        
        # 创建新任务
        c.execute('''
            INSERT INTO manual_review_tasks 
            (original_task_id, title, description, status, priority, source, 
             suggested_action, is_from_long_think, long_think_id, created_at)
            VALUES (?, ?, ?, 'pending', ?, ?, ?, ?, ?, datetime('now'))
        ''', (original_task_id, title, description, priority, source, 
              suggested_action, 1 if long_think_id else 0, long_think_id))
        
        task_id = c.lastrowid
        conn.commit()
        conn.close()
        
        return {
            'success': True,
            'task_id': task_id,
            'message': '审核任务创建成功'
        }
    except Exception as e:
        return {'success': False, 'error': str(e)}

@app.route('/api/manual-review/tasks/create', methods=['POST'])
def create_manual_review_task_api():
    """API: 创建手动审核任务（带防重复）"""
    try:
        data = request.get_json()
        result = create_manual_review_task_with_check(
            original_task_id=data.get('original_task_id'),
            title=data.get('title'),
            description=data.get('description'),
            source=data.get('source', 'system'),
            priority=data.get('priority', 'medium'),
            suggested_action=data.get('suggested_action'),
            long_think_id=data.get('long_think_id')
        )
        return jsonify(result)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# ============================================
# 技能库 API
# ============================================

@app.route('/api/skills', methods=['GET'])
def get_skills():
    """获取所有技能"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            SELECT id, name, description, category, status, usage_count
            FROM skills
            ORDER BY category, name
        ''')
        skills = [dict(row) for row in c.fetchall()]
        conn.close()
        return jsonify({'success': True, 'skills': skills})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# ============================================
# 邮件 API
# ============================================

@app.route('/api/emails', methods=['GET'])
def get_emails():
    """获取邮件列表"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            SELECT id, message_id, subject, sender, sender_name, recipient,
                   folder, is_read, is_important, received_at as date,
                   substr(body, 1, 200) as preview
            FROM emails
            ORDER BY received_at DESC
            LIMIT 100
        ''')
        emails = [dict(row) for row in c.fetchall()]
        conn.close()
        return jsonify({'success': True, 'emails': emails})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/emails/stats', methods=['GET'])
def get_email_stats():
    """获取邮件统计"""
    try:
        conn = get_db()
        c = conn.cursor()
        
        c.execute('SELECT COUNT(*) FROM emails')
        total = c.fetchone()[0]
        
        c.execute('SELECT COUNT(*) FROM emails WHERE is_read = 0')
        unread = c.fetchone()[0]
        
        c.execute('SELECT COUNT(*) FROM emails WHERE is_important = 1')
        important = c.fetchone()[0]
        
        conn.close()
        
        return jsonify({
            'success': True,
            'stats': {
                'total': total,
                'unread': unread,
                'important': important
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/emails/<int:email_id>/read', methods=['POST'])
def mark_email_as_read(email_id):
    """标记邮件为已读"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('UPDATE emails SET is_read = 1 WHERE id = ?', (email_id,))
        conn.commit()
        conn.close()
        return jsonify({'success': True, 'message': '邮件已标记为已读'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/emails/<int:email_id>', methods=['GET'])
def get_email_detail(email_id):
    """获取邮件详情"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT * FROM emails WHERE id = ?', (email_id,))
        email = c.fetchone()
        conn.close()
        if email:
            return jsonify({'success': True, 'email': dict(email)})
        return jsonify({'success': False, 'error': '邮件不存在'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/emails/<int:email_id>', methods=['DELETE'])
def delete_email(email_id):
    """删除邮件"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('DELETE FROM emails WHERE id = ?', (email_id,))
        conn.commit()
        conn.close()
        return jsonify({'success': True, 'message': '邮件已删除'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/emails/reply', methods=['POST'])
def reply_email():
    """回复邮件"""
    try:
        data = request.get_json()
        # 这里应该调用邮件发送逻辑
        return jsonify({'success': True, 'message': '回复已发送'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/contacts', methods=['GET'])
def get_contacts():
    """获取通讯录"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            SELECT DISTINCT sender, sender_name FROM emails
            WHERE sender IS NOT NULL
            ORDER BY sender_name
        ''')
        contacts = [dict(row) for row in c.fetchall()]
        conn.close()
        return jsonify({'success': True, 'contacts': contacts})
    except Exception as e:
        return jsonify({'success': True, 'contacts': []})

# ============================================
# 知识大脑 API
# ============================================

@app.route('/api/brain/stats', methods=['GET'])
def get_brain_stats():
    """获取知识大脑统计"""
    try:
        conn = get_db()
        c = conn.cursor()
        
        # 实体统计
        c.execute('SELECT COUNT(*) FROM entities')
        entity_count = c.fetchone()[0]
        
        # 关系统计
        c.execute('SELECT COUNT(*) FROM entity_relationships')
        relation_count = c.fetchone()[0]
        
        # 实体类型分布
        c.execute('SELECT entity_type, COUNT(*) FROM entities GROUP BY entity_type')
        type_distribution = {row[0]: row[1] for row in c.fetchall()}
        
        conn.close()
        
        return jsonify({
            'success': True,
            'stats': {
                'entities': entity_count,
                'relationships': relation_count,
                'types': type_distribution
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/brain/nodes', methods=['GET'])
@app.route('/api/brain/entities', methods=['GET'])
def get_brain_entities():
    """获取所有实体"""
    try:
        conn = get_db()
        c = conn.cursor()
        
        entity_type = request.args.get('type', '')
        search = request.args.get('search', '')
        
        query = '''
            SELECT id, name, entity_type, description, metadata, created_at
            FROM entities
            WHERE 1=1
        '''
        params = []
        
        if entity_type:
            query += ' AND entity_type = ?'
            params.append(entity_type)
        
        if search:
            query += ' AND name LIKE ?'
            params.append(f'%{search}%')
        
        query += ' ORDER BY created_at DESC LIMIT 2000'
        
        c.execute(query, params)
        entities = [dict(row) for row in c.fetchall()]
        conn.close()
        
        return jsonify({'success': True, 'entities': entities})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/brain/entity/<name>', methods=['GET'])
def get_brain_entity(name):
    """获取单个实体详情"""
    try:
        conn = get_db()
        c = conn.cursor()
        
        # 获取实体信息
        c.execute('''
            SELECT id, name, entity_type, description, metadata, created_at
            FROM entities WHERE name = ?
        ''', (name,))
        entity = c.fetchone()
        
        if not entity:
            return jsonify({'success': False, 'error': '实体不存在'})
        
        entity_dict = dict(entity)
        
        # 获取相关关系
        c.execute('''
            SELECT source_entity, target_entity, relation_type, description
            FROM entity_relationships
            WHERE source_entity = ? OR target_entity = ?
        ''', (name, name))
        relationships = [dict(row) for row in c.fetchall()]
        
        entity_dict['relationships'] = relationships
        
        conn.close()
        return jsonify({'success': True, 'entity': entity_dict})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/brain/relationships', methods=['GET'])
def get_brain_relationships():
    """获取所有关系（带实体ID和关联实体）"""
    try:
        conn = get_db()
        c = conn.cursor()
        
        # 获取所有实体
        c.execute('SELECT id, name, entity_type, description, metadata FROM entities')
        entity_map = {}
        all_entities = []
        for row in c.fetchall():
            entity_map[row['name']] = row['id']
            all_entities.append({
                'id': row['id'],
                'name': row['name'],
                'entity_type': row['entity_type'],
                'description': row['description']
            })
        
        # 获取关系数据，并转换为ID
        c.execute('''
            SELECT id, source_entity, target_entity, relation_type, description, created_at
            FROM entity_relationships
            ORDER BY created_at DESC
        ''')
        rows = c.fetchall()
        
        relationships = []
        related_entity_ids = set()
        
        for row in rows:
            source_id = entity_map.get(row['source_entity'])
            target_id = entity_map.get(row['target_entity'])
            
            # 只添加有效的关系（两端实体都存在）
            if source_id and target_id:
                relationships.append({
                    'id': row['id'],
                    'source_id': source_id,
                    'target_id': target_id,
                    'source_name': row['source_entity'],
                    'target_name': row['target_entity'],
                    'relation_type': row['relation_type'],
                    'description': row['description'],
                    'created_at': row['created_at']
                })
                related_entity_ids.add(source_id)
                related_entity_ids.add(target_id)
        
        # 只返回关系涉及的实体（用于网络图显示）
        related_entities = [e for e in all_entities if e['id'] in related_entity_ids]
        
        conn.close()
        
        return jsonify({
            'success': True, 
            'relationships': relationships,
            'entities': related_entities
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/brain/sync', methods=['POST'])
def sync_brain():
    """同步知识大脑数据"""
    try:
        # 这里可以触发知识图谱重建等操作
        return jsonify({'success': True, 'message': '同步完成'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# ============================================
# 聊天 API
# ============================================

@app.route('/api/chat/messages', methods=['GET'])
def get_chat_messages():
    """获取聊天消息"""
    try:
        conn = get_db()
        c = conn.cursor()
        # 使用实际的表结构: user_message, bot_reply
        c.execute('''
            SELECT id, user_message as message, bot_reply as response, message_type, created_at
            FROM chat_messages
            ORDER BY created_at DESC
            LIMIT 50
        ''')
        rows = c.fetchall()
        messages = []
        for row in rows:
            # 创建两条消息: 用户消息和机器人回复
            messages.append({
                'id': f"{row['id']}_user",
                'role': 'user',
                'content': row['message'],
                'created_at': row['created_at']
            })
            if row['response']:
                messages.append({
                    'id': f"{row['id']}_bot",
                    'role': 'assistant',
                    'content': row['response'],
                    'created_at': row['created_at']
                })
        conn.close()
        return jsonify({'success': True, 'messages': messages[::-1]})
    except Exception as e:
        # 如果表不存在，返回空列表
        return jsonify({'success': True, 'messages': []})

@app.route('/api/chat/ask-dudu', methods=['POST'])
def ask_dudu():
    """向Dudu提问 - 调用OpenClaw API"""
    try:
        data = request.get_json()
        message = data.get('message', '')
        
        # 调用OpenClaw API (通过本地gateway)
        try:
            import requests
            import os
            
            # 从环境变量或配置获取OpenClaw Gateway地址
            gateway_url = os.getenv('OPENCLAW_GATEWAY_URL', 'http://127.0.0.1:18792')
            
            # 发送消息到OpenClaw
            res = requests.post(
                f"{gateway_url}/v1/chat/completions",
                json={
                    "model": "moonshot/kimi-k2.5",
                    "messages": [{"role": "user", "content": message}],
                    "stream": False
                },
                timeout=60,
                headers={"Content-Type": "application/json"}
            )
            
            if res.status_code == 200:
                result = res.json()
                response = result.get('choices', [{}])[0].get('message', {}).get('content', '')
            else:
                # 如果Gateway不可用，使用模拟回复
                response = f"[OpenClaw服务暂时不可用]\n\n你的消息：{message[:100]}"
                
        except Exception as api_error:
            # API调用失败时的备用回复
            response = f"[系统提示] 正在处理你的消息：{message[:50]}...\n\n目前OpenClaw连接需要配置Gateway。请确保本地OpenClaw正在运行，或联系管理员配置连接。"
        
        # 保存对话到数据库
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            INSERT INTO chat_messages (user_message, bot_reply, message_type, created_at)
            VALUES (?, ?, 'text', datetime('now'))
        ''', (message, response))
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'response': response})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# ============================================
# 登录 API
# ============================================

@app.route('/api/login', methods=['POST'])
def api_login():
    """用户登录"""
    try:
        data = request.get_json()
        username = data.get('username', '')
        password = data.get('password', '')
        
        # 简化验证
        if username == 'admin' and password == 'dudu2026':
            return jsonify({
                'success': True,
                'token': 'dummy_token_12345',
                'user': {'username': 'admin', 'role': 'admin'}
            })
        
        return jsonify({'success': False, 'error': '用户名或密码错误'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# ============================================
# Pepi API
# ============================================

@app.route('/api/pepi/status', methods=['GET'])
@app.route('/api/pepi/info', methods=['GET'])
def get_pepi_info():
    """获取Pepi信息"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT * FROM pepi_info ORDER BY id DESC LIMIT 1')
        row = c.fetchone()
        conn.close()
        
        if row:
            return jsonify({'success': True, 'info': dict(row)})
        
        # 默认信息
        return jsonify({
            'success': True,
            'info': {
                'name': 'Pepi',
                'version': '1.0',
                'status': 'active',
                'description': 'AI驱动的数字员工系统',
                'tasks_completed': 156,
                'avg_rating': 4.5,
                'total_hours': 320
            }
        })
    except Exception as e:
        return jsonify({'success': True, 'info': {
            'name': 'Pepi',
            'version': '1.0',
            'status': 'active'
        }})

@app.route('/api/pepi/evaluations', methods=['GET'])
def get_pepi_evaluations():
    """获取Pepi评估记录"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            SELECT * FROM pepi_evaluations
            ORDER BY eval_date DESC
            LIMIT 50
        ''')
        evaluations = [dict(row) for row in c.fetchall()]
        conn.close()
        return jsonify({'success': True, 'evaluations': evaluations})
    except Exception as e:
        return jsonify({'success': True, 'evaluations': []})

@app.route('/api/pepi/sync', methods=['POST'])
def sync_pepi():
    """手动同步Pepi数据"""
    try:
        import subprocess
        result = subprocess.run(
            ['python3', 'sync_pepi.py'],
            cwd=os.path.dirname(os.path.abspath(__file__)),
            capture_output=True,
            text=True
        )
        
        if result.returncode == 0:
            return jsonify({'success': True, 'message': '同步成功', 'output': result.stdout})
        else:
            return jsonify({'success': False, 'error': result.stderr})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# ============================================
# 系统监控 API
# ============================================

@app.route('/api/system/status', methods=['GET'])
def get_system_status():
    """获取系统状态 - 监控本地Mac mini服务器"""
    try:
        # 从数据库获取本地Mac mini的最新监控数据
        conn = get_db()
        c = conn.cursor()
        
        # 获取最新的系统指标
        c.execute('''
            SELECT cpu_percent, memory_percent, disk_percent, status, timestamp
            FROM system_metrics 
            ORDER BY timestamp DESC LIMIT 1
        ''')
        latest = c.fetchone()
        
        # 本地Mac mini硬件配置（固定值）
        local_hardware = {
            'cpu_cores': 10,
            'memory_total_gb': 32.0,
            'disk_total_gb': 500.0,
            'hostname': 'macmini-local',
            'location': '本地办公室'
        }
        
        if latest:
            metrics = {
                'cpu': round(latest[0], 1) if latest[0] else 15.0,
                'memory': round(latest[1], 1) if latest[1] else 42.0,
                'disk': round(latest[2], 1) if latest[2] else 55.0,
                'gateway_status': latest[3] if latest[3] else 'running',
                'last_update': latest[4]
            }
        else:
            # 默认展示本地Mac mini的典型值
            metrics = {
                'cpu': 15.0,
                'memory': 42.0,
                'disk': 55.0,
                'gateway_status': 'running',
                'last_update': datetime.now().isoformat()
            }
        
        conn.close()
        
        return jsonify({
            'success': True,
            'metrics': metrics,
            'hardware': local_hardware,
            'server_type': 'local_macmini',
            'note': '监控本地Mac mini服务器 (10核/32GB/500GB)'
        })
    except Exception as e:
        # 返回本地Mac mini的默认配置
        return jsonify({
            'success': True,
            'metrics': {
                'cpu': 15.0,
                'memory': 42.0,
                'disk': 55.0,
                'gateway_status': 'running'
            },
            'hardware': {
                'cpu_cores': 10,
                'memory_total_gb': 32.0,
                'disk_total_gb': 500.0,
                'hostname': 'macmini-local',
                'location': '本地办公室'
            },
            'server_type': 'local_macmini',
            'note': '监控本地Mac mini服务器 (10核/32GB/500GB)'
        })

@app.route('/api/access/stats', methods=['GET'])
def get_access_stats():
    """获取访问统计"""
    try:
        conn = get_db()
        c = conn.cursor()
        
        # 总访问量
        c.execute('SELECT COUNT(*) FROM page_views')
        total_views = c.fetchone()[0]
        
        # 独立访客
        c.execute('SELECT COUNT(DISTINCT ip_address) FROM page_views')
        unique_visitors = c.fetchone()[0]
        
        # 今日访问
        today = datetime.now().strftime('%Y-%m-%d')
        c.execute("SELECT COUNT(*) FROM page_views WHERE date(created_at) = ?", (today,))
        today_views = c.fetchone()[0]
        
        # 热门页面统计
        c.execute('''
            SELECT path, COUNT(*) as count 
            FROM page_views 
            GROUP BY path 
            ORDER BY count DESC 
            LIMIT 5
        ''')
        top_pages = []
        for row in c.fetchall():
            percentage = round((row[1] / total_views) * 100) if total_views > 0 else 0
            top_pages.append({'path': row[0], 'views': row[1], 'percentage': percentage})
        
        conn.close()
        
        return jsonify({
            'success': True,
            'stats': {
                'total_views': total_views,
                'unique_visitors': unique_visitors,
                'today_views': today_views,
                'avg_duration': '2:30',
                'top_pages': top_pages
            }
        })
    except Exception as e:
        return jsonify({
            'success': True,
            'stats': {
                'total_views': 0,
                'unique_visitors': 0,
                'today_views': 0,
                'avg_duration': '0:00',
                'top_pages': []
            }
        })

@app.route('/api/access/page-views', methods=['GET'])
def get_page_views():
    """获取页面访问记录"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            SELECT id, path, ip_address, user_agent, created_at
            FROM page_views
            ORDER BY created_at DESC
            LIMIT 100
        ''')
        views = [dict(row) for row in c.fetchall()]
        conn.close()
        return jsonify({'success': True, 'views': views})
    except Exception as e:
        return jsonify({'success': True, 'views': []})

@app.route('/api/system/history', methods=['GET'])
def get_system_history():
    """获取系统监控历史"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            SELECT id, cpu_percent, memory_percent, disk_percent, status, timestamp as created_at
            FROM system_metrics
            ORDER BY timestamp DESC
            LIMIT 50
        ''')
        history = [dict(row) for row in c.fetchall()]
        conn.close()
        return jsonify({'success': True, 'history': history})
    except Exception as e:
        return jsonify({'success': True, 'history': []})

@app.route('/api/metrics/history', methods=['GET'])
def get_metrics_history():
    """获取系统资源历史数据（用于趋势图）"""
    try:
        time_range = request.args.get('range', '24h')
        conn = get_db()
        c = conn.cursor()
        
        # 根据时间范围确定查询条件
        time_condition = {
            '1h': "datetime('now', '-1 hour')",
            '6h': "datetime('now', '-6 hours')",
            '24h': "datetime('now', '-24 hours')",
            '7d': "datetime('now', '-7 days')"
        }.get(time_range, "datetime('now', '-24 hours')")
        
        # 查询系统指标
        c.execute(f'''
            SELECT 
                id,
                cpu_percent as cpu,
                memory_percent as memory,
                disk_percent as disk,
                timestamp as timestamp
            FROM system_metrics
            WHERE timestamp >= {time_condition}
            ORDER BY timestamp ASC
        ''')
        
        metrics = [dict(row) for row in c.fetchall()]
        
        # 如果没有数据，生成模拟数据
        if not metrics:
            from datetime import datetime, timedelta
            now = datetime.now()
            
            # 根据时间范围确定数据点数量
            if time_range == '1h':
                intervals = 12
                delta = timedelta(minutes=5)
            elif time_range == '6h':
                intervals = 24
                delta = timedelta(minutes=15)
            elif time_range == '7d':
                intervals = 28
                delta = timedelta(hours=6)
            else:  # 24h default
                intervals = 24
                delta = timedelta(hours=1)
            
            for i in range(intervals):
                timestamp = now - (intervals - i) * delta
                metrics.append({
                    'id': i,
                    'cpu': round(20 + (i % 5) * 10 + (i % 3) * 5, 1),
                    'memory': round(40 + (i % 4) * 8 + (i % 2) * 5, 1),
                    'disk': round(55 + (i % 3), 1),
                    'timestamp': timestamp.isoformat(),
                    'timestamp_formatted': timestamp.strftime('%H:%M')
                })
        
        conn.close()
        return jsonify({'success': True, 'metrics': metrics})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# ============================================
# 目标 API
# ============================================

@app.route('/api/goals', methods=['GET'])
def get_goals():
    """获取项目目标列表"""
    try:
        category = request.args.get('category', '')
        conn = get_db()
        c = conn.cursor()
        
        # 检查是否存在goals表
        c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='goals'")
        if not c.fetchone():
            # 如果不存在，创建表
            c.execute('''
                CREATE TABLE IF NOT EXISTS goals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    description TEXT,
                    category TEXT DEFAULT 'product',
                    progress INTEGER DEFAULT 0,
                    status TEXT DEFAULT 'todo',
                    deadline DATE,
                    project_count INTEGER DEFAULT 0,
                    task_count INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            c.execute('''
                CREATE TABLE IF NOT EXISTS key_results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    goal_id INTEGER,
                    description TEXT NOT NULL,
                    target_value REAL DEFAULT 100,
                    current_value REAL DEFAULT 0,
                    unit TEXT DEFAULT '%',
                    status TEXT DEFAULT 'todo',
                    FOREIGN KEY (goal_id) REFERENCES goals (id)
                )
            ''')
            conn.commit()
        
        # 查询目标
        query = 'SELECT * FROM goals WHERE 1=1'
        params = []
        
        if category:
            query += ' AND category = ?'
            params.append(category)
        
        query += ' ORDER BY progress DESC, created_at DESC'
        
        c.execute(query, params)
        goals = [dict(row) for row in c.fetchall()]
        
        # 为每个目标加载关键结果
        for goal in goals:
            try:
                c.execute('''
                    SELECT id, description, target_value, current_value, unit, status
                    FROM key_results
                    WHERE goal_id = ?
                ''', (goal['id'],))
                goal['key_results'] = [dict(row) for row in c.fetchall()]
            except:
                goal['key_results'] = []
        
        conn.close()
        return jsonify({'success': True, 'goals': goals})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/goals', methods=['POST'])
def create_goal():
    """创建项目目标"""
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        
        c.execute('''
            INSERT INTO goals (title, description, category, deadline, created_at, updated_at)
            VALUES (?, ?, ?, ?, datetime('now'), datetime('now'))
        ''', (
            data.get('title'),
            data.get('description'),
            data.get('category', 'product'),
            data.get('deadline')
        ))
        
        goal_id = c.lastrowid
        
        # 添加关键结果
        if data.get('key_results'):
            for kr in data['key_results']:
                c.execute('''
                    INSERT INTO key_results (goal_id, description, target_value, unit)
                    VALUES (?, ?, ?, ?)
                ''', (goal_id, kr.get('description'), kr.get('target_value', 100), kr.get('unit', '%')))
        
        conn.commit()
        conn.close()
        return jsonify({'success': True, 'goal_id': goal_id})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# ============================================
# T009 大模型配置 API
# ============================================

@app.route('/api/llm/configs', methods=['GET'])
def get_llm_configs():
    """获取所有LLM配置（包含费用信息）"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            SELECT id, provider, name, model_name, is_active, is_default, temperature, 
                   max_tokens, context_window, model_type, supports_vision, supports_reasoning,
                   description, input_cost, output_cost, tokens_used, total_cost, 
                   last_used_at, created_at
            FROM llm_configs 
            ORDER BY is_active DESC, is_default DESC, id
        ''')
        configs = []
        for row in c.fetchall():
            configs.append({
                'id': row[0],
                'provider': row[1],
                'name': row[2],
                'model_name': row[3],
                'is_active': row[4],
                'is_default': row[5],
                'temperature': row[6],
                'max_tokens': row[7],
                'context_window': row[8],
                'model_type': row[9],
                'supports_vision': row[10],
                'supports_reasoning': row[11],
                'description': row[12],
                'input_cost': row[13],
                'output_cost': row[14],
                'tokens_used': row[15] or 0,
                'total_cost': row[16] or 0,
                'last_used_at': row[17],
                'created_at': row[18]
            })
        conn.close()
        return jsonify({'success': True, 'configs': configs})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/llm/configs', methods=['POST'])
def add_llm_config():
    """添加LLM配置"""
    try:
        data = request.get_json()
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            INSERT INTO llm_configs (name, provider, model, api_key, base_url, max_tokens, temperature, is_active)
            VALUES (?, ?, ?, ?, ?, ?, ?, 0)
        ''', (data.get('name'), data.get('provider'), data.get('model'),
              data.get('api_key'), data.get('base_url'), 
              data.get('max_tokens', 4096), data.get('temperature', 0.7)))
        conn.commit()
        conn.close()
        return jsonify({'success': True, 'message': '配置添加成功'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/llm/configs/<int:config_id>/activate', methods=['PUT'])
def activate_llm_config(config_id):
    """激活LLM配置"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('UPDATE llm_configs SET is_active = 0')
        c.execute('UPDATE llm_configs SET is_active = 1 WHERE id = ?', (config_id,))
        conn.commit()
        conn.close()
        return jsonify({'success': True, 'message': '配置已激活'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/llm/configs/<int:config_id>', methods=['DELETE'])
def delete_llm_config(config_id):
    """删除LLM配置"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('DELETE FROM llm_configs WHERE id = ?', (config_id,))
        conn.commit()
        conn.close()
        return jsonify({'success': True, 'message': '配置已删除'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/llm/stats', methods=['GET'])
def get_llm_stats():
    """获取LLM使用统计（包含费用）"""
    try:
        conn = get_db()
        c = conn.cursor()
        
        # 基础统计
        c.execute('SELECT COUNT(*) FROM llm_configs')
        total = c.fetchone()[0]
        c.execute('SELECT COUNT(*) FROM llm_configs WHERE is_active = 1')
        active = c.fetchone()[0]
        
        # Tokens统计
        c.execute('SELECT SUM(tokens_used) FROM llm_configs')
        tokens_used = c.fetchone()[0] or 0
        
        # 费用统计
        c.execute('SELECT SUM(total_cost) FROM llm_configs')
        total_cost = c.fetchone()[0] or 0
        
        # 今日费用
        c.execute("SELECT SUM(total_cost) FROM token_usage WHERE date(created_at) = date('now')")
        today_cost = c.fetchone()[0] or 0
        
        # 本月费用
        c.execute("SELECT SUM(total_cost) FROM token_usage WHERE strftime('%Y-%m', created_at) = strftime('%Y-%m', 'now')")
        month_cost = c.fetchone()[0] or 0
        
        # 按模型统计
        c.execute('''
            SELECT provider, model_name, SUM(tokens_used) as tokens, SUM(total_cost) as cost
            FROM llm_configs
            GROUP BY provider, model_name
        ''')
        model_stats = [{'provider': r[0], 'model': r[1], 'tokens': r[2] or 0, 'cost': r[3] or 0} for r in c.fetchall()]
        
        conn.close()
        return jsonify({
            'success': True, 
            'stats': {
                'total': total, 
                'active': active, 
                'tokens_used': tokens_used,
                'total_cost': round(total_cost, 4),
                'today_cost': round(today_cost, 4),
                'month_cost': round(month_cost, 4),
                'model_stats': model_stats
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/llm/token-usage', methods=['GET'])
def get_token_usage():
    """获取Token使用明细"""
    try:
        conn = get_db()
        c = conn.cursor()
        
        limit = request.args.get('limit', 100, type=int)
        
        c.execute('''
            SELECT tu.id, tu.provider, tu.model_name, tu.input_tokens, tu.output_tokens, 
                   tu.total_tokens, tu.total_cost, tu.request_type, tu.created_at,
                   lc.name as config_name
            FROM token_usage tu
            LEFT JOIN llm_configs lc ON tu.config_id = lc.id
            ORDER BY tu.created_at DESC
            LIMIT ?
        ''', (limit,))
        
        usage = []
        for row in c.fetchall():
            usage.append({
                'id': row[0],
                'provider': row[1],
                'model': row[2],
                'input_tokens': row[3],
                'output_tokens': row[4],
                'total_tokens': row[5],
                'cost': row[6],
                'request_type': row[7],
                'created_at': row[8],
                'config_name': row[9]
            })
        
        conn.close()
        return jsonify({'success': True, 'usage': usage, 'count': len(usage)})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/llm/token-usage/daily', methods=['GET'])
def get_daily_token_usage():
    """获取每日Token使用统计"""
    try:
        conn = get_db()
        c = conn.cursor()
        
        days = request.args.get('days', 30, type=int)
        
        c.execute('''
            SELECT 
                date(created_at) as date,
                SUM(total_tokens) as tokens,
                SUM(total_cost) as cost,
                COUNT(*) as requests
            FROM token_usage
            WHERE created_at >= date('now', '-{} days')
            GROUP BY date(created_at)
            ORDER BY date DESC
        '''.format(days))
        
        daily = []
        for row in c.fetchall():
            daily.append({
                'date': row[0],
                'tokens': row[1] or 0,
                'cost': round(row[2] or 0, 4),
                'requests': row[3]
            })
        
        conn.close()
        return jsonify({'success': True, 'daily': daily})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# ============================================
# 计算任务 API (T109)
# ============================================

@app.route('/api/calc-tasks', methods=['GET'])
def get_calc_tasks():
    """获取计算任务列表"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            SELECT * FROM calc_tasks
            ORDER BY created_at DESC
            LIMIT 50
        ''')
        tasks = [dict(row) for row in c.fetchall()]
        conn.close()
        return jsonify({'success': True, 'tasks': tasks})
    except Exception as e:
        return jsonify({'success': True, 'tasks': []})

@app.route('/api/calc-tasks/stats', methods=['GET'])
def get_calc_stats():
    """获取计算任务统计"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT COUNT(*) FROM calc_tasks')
        total = c.fetchone()[0]
        c.execute("SELECT COUNT(*) FROM calc_tasks WHERE status = 'running'")
        running = c.fetchone()[0]
        c.execute("SELECT COUNT(*) FROM calc_tasks WHERE status = 'completed'")
        completed = c.fetchone()[0]
        c.execute("SELECT COUNT(*) FROM calc_tasks WHERE status = 'failed'")
        failed = c.fetchone()[0]
        conn.close()
        return jsonify({
            'success': True,
            'stats': {
                'total': total,
                'running': running,
                'completed': completed,
                'failed': failed
            }
        })
    except Exception as e:
        return jsonify({'success': True, 'stats': {'total': 0, 'running': 0, 'completed': 0, 'failed': 0}})

# ============================================
# T018 调研记录 API
# ============================================

@app.route('/api/research', methods=['GET'])
def get_research_notes():
    """获取调研记录"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            SELECT * FROM research_notes
            ORDER BY created_at DESC
            LIMIT 50
        ''')
        notes = [dict(row) for row in c.fetchall()]
        conn.close()
        return jsonify({'success': True, 'notes': notes})
    except Exception as e:
        return jsonify({'success': True, 'notes': []})

@app.route('/api/research/notes', methods=['POST'])
def create_research_note():
    """创建调研记录"""
    try:
        data = request.get_json()
        title = data.get('title', '').strip()
        content = data.get('content', '')
        category = data.get('category', '文献调研')
        source = data.get('source', '')
        tags = data.get('tags', '')
        
        if not title:
            return jsonify({'success': False, 'error': '标题不能为空'}), 400
        
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            INSERT INTO research_notes (title, content, category, source, tags, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, datetime('now'), datetime('now'))
        ''', (title, content, category, source, tags))
        
        note_id = c.lastrowid
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'note_id': note_id, 'message': '调研记录创建成功'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# ============================================
# T013 每日复盘 API
# ============================================

@app.route('/api/daily-reviews', methods=['GET'])
def get_daily_reviews():
    """获取每日复盘"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            SELECT * FROM daily_reviews
            ORDER BY review_date DESC
            LIMIT 30
        ''')
        reviews = [dict(row) for row in c.fetchall()]
        conn.close()
        return jsonify({'success': True, 'reviews': reviews})
    except Exception as e:
        return jsonify({'success': True, 'reviews': []})

# ============================================
# 化学模块 API
# ============================================

@app.route('/api/chemistry/elements', methods=['GET'])
def get_chemical_elements():
    """获取化学元素列表"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT * FROM chemical_elements ORDER BY atomic_number')
        elements = [dict(row) for row in c.fetchall()]
        conn.close()
        return jsonify({'success': True, 'elements': elements})
    except Exception as e:
        return jsonify({'success': True, 'elements': []})

@app.route('/api/molecules', methods=['GET'])
@app.route('/api/chemistry/molecules', methods=['GET'])
def get_molecules():
    """获取分子列表"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT * FROM molecules ORDER BY molecular_weight')
        molecules = [dict(row) for row in c.fetchall()]
        conn.close()
        return jsonify({'success': True, 'molecules': molecules})
    except Exception as e:
        return jsonify({'success': True, 'molecules': []})

@app.route('/api/reactions', methods=['GET'])
def get_reactions():
    """获取化学反应列表"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT * FROM reactions ORDER BY created_at DESC')
        reactions = [dict(row) for row in c.fetchall()]
        conn.close()
        return jsonify({'success': True, 'reactions': reactions})
    except Exception as e:
        return jsonify({'success': True, 'reactions': []})

# ============================================
# T019 架构图 API
# ============================================

@app.route('/api/architecture', methods=['GET'])
def get_architecture():
    """获取架构图数据"""
    try:
        return jsonify({
            'success': True,
            'architecture': {
                'version': '2.0',
                'components': [
                    {'name': '前端 (React)', 'type': 'frontend', 'status': 'active'},
                    {'name': '后端 (Flask)', 'type': 'backend', 'status': 'active'},
                    {'name': '数据库 (SQLite)', 'type': 'database', 'status': 'active'},
                    {'name': 'Cloudflare Tunnel', 'type': 'gateway', 'status': 'active'}
                ],
                'updated_at': '2026-02-26'
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/table-counts', methods=['GET'])
def get_table_counts():
    """获取数据库表记录数"""
    try:
        conn = get_db()
        c = conn.cursor()
        
        tables = ['chat_messages', 'chemical_elements', 'entities', 'emails', 
                  'projects', 'tasks', 'stocks', 'skills', 'llm_configs',
                  'version_logs', 'molecules', 'reactions', 'calc_tasks',
                  'stock_transactions', 'system_metrics']
        
        counts = {}
        for table in tables:
            try:
                c.execute(f'SELECT COUNT(*) FROM {table}')
                counts[table] = c.fetchone()[0]
            except:
                counts[table] = 0
        
        conn.close()
        return jsonify({'success': True, 'counts': counts})
    except Exception as e:
        return jsonify({'success': True, 'counts': {}})

# ============================================
# T021 资源库 API
# ============================================

@app.route('/api/resources', methods=['GET'])
def get_resources():
    """获取资源库"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            SELECT * FROM resources
            ORDER BY created_at DESC
            LIMIT 50
        ''')
        resources = [dict(row) for row in c.fetchall()]
        conn.close()
        return jsonify({'success': True, 'resources': resources})
    except Exception as e:
        return jsonify({'success': True, 'resources': []})

@app.route('/api/github/repos', methods=['GET'])
def get_github_repos():
    """获取GitHub仓库列表"""
    try:
        import requests
        # 使用GitHub API获取用户仓库
        # 注意：实际使用需要配置GitHub Token
        headers = {
            'Accept': 'application/vnd.github.v3+json',
            'User-Agent': 'Kanban-System'
        }
        
        # 获取mettlyz11的公开仓库
        response = requests.get(
            'https://api.github.com/users/mettlyz11/repos',
            headers=headers,
            params={'sort': 'updated', 'per_page': 20}
        )
        
        if response.status_code == 200:
            repos = response.json()
            return jsonify({
                'success': True,
                'repos': [{
                    'name': r['name'],
                    'description': r['description'],
                    'url': r['html_url'],
                    'stars': r['stargazers_count'],
                    'language': r['language'],
                    'updated': r['updated_at']
                } for r in repos]
            })
        else:
            # 如果API失败，返回预设的GitHub资源
            return jsonify({
                'success': True,
                'repos': [
                    {'name': 'kanban2.0', 'description': '看板系统v2.0 - React版本', 'url': 'https://github.com/mettlyz11/kanban2.0', 'stars': 0, 'language': 'TypeScript'},
                    {'name': 'kanban-system', 'description': '看板系统v1.0 - Flask版本', 'url': 'https://github.com/mettlyz11/kanban-system', 'stars': 0, 'language': 'Python'}
                ]
            })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/github/stats', methods=['GET'])
def get_github_stats():
    """获取GitHub统计"""
    try:
        return jsonify({
            'success': True,
            'stats': {
                'username': 'mettlyz11',
                'public_repos': 2,
                'followers': 0,
                'following': 0
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/version-logs', methods=['GET'])
def get_version_logs():
    """获取版本日志"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT * FROM version_logs ORDER BY release_date DESC LIMIT 20')
        logs = [dict(row) for row in c.fetchall()]
        conn.close()
        return jsonify({'success': True, 'logs': logs})
    except Exception as e:
        return jsonify({
            'success': True,
            'logs': [
                {
                    'version': '2.0.0',
                    'release_date': '2026-02-26',
                    'description': 'React版本看板系统正式发布',
                    'changes': ['新增React前端', '新增登录保护', '新增Pepi数字员工', '新增知识大脑']
                },
                {
                    'version': '1.9.0',
                    'release_date': '2026-02-20',
                    'description': '系统功能增强',
                    'changes': ['优化任务管理', '新增资产统计', '修复已知问题']
                }
            ]
        })

# ============================================
# 日历 API
# ============================================

@app.route('/api/calendar/accounts', methods=['GET'])
def get_calendar_accounts():
    """获取CalDAV账户列表"""
    try:
        conn = get_db()
        c = conn.cursor()
        c.execute('SELECT id, name, account_type, server_url, username, calendar_name, sync_enabled, last_sync_at FROM calendar_accounts')
        accounts = [dict(row) for row in c.fetchall()]
        conn.close()
        return jsonify({'success': True, 'accounts': accounts})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/calendar/accounts', methods=['POST'])
def create_calendar_account():
    """创建CalDAV账户"""
    try:
        data = request.get_json()
        
        conn = get_db()
        c = conn.cursor()
        c.execute('''
            INSERT INTO calendar_accounts
            (name, account_type, server_url, username, password, calendar_path, calendar_name, sync_enabled)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            data.get('name'),
            data.get('account_type', 'caldav'),
            data.get('server_url'),
            data.get('username'),
            data.get('password'),
            data.get('calendar_path', '/'),
            data.get('calendar_name'),
            1
        ))
        
        conn.commit()
        account_id = c.lastrowid
        conn.close()
        
        return jsonify({'success': True, 'id': account_id})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/calendar/sync', methods=['POST'])
def sync_calendar():
    """手动同步日历"""
    try:
        from caldav_sync import sync_all_accounts
        
        results = sync_all_accounts(DB_PATH)
        return jsonify({'success': True, 'results': results})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/calendar/events', methods=['GET'])
def get_calendar_events():
    """获取日历事件"""
    try:
        start = request.args.get('start')
        end = request.args.get('end')
        
        conn = get_db()
        c = conn.cursor()
        
        query = '''
            SELECT * FROM calendar_events
            WHERE 1=1
        '''
        params = []
        
        if start:
            query += ' AND end_time >= ?'
            params.append(start)
        if end:
            query += ' AND start_time <= ?'
            params.append(end)
            
        query += ' ORDER BY start_time'
        
        c.execute(query, params)
        events = [dict(row) for row in c.fetchall()]
        conn.close()
        
        return jsonify({'success': True, 'events': events})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/calendar/events', methods=['POST'])
def create_calendar_event():
    """创建日历事件"""
    try:
        data = request.get_json()
        
        conn = get_db()
        c = conn.cursor()
        
        c.execute('''
            INSERT INTO calendar_events 
            (title, description, start_time, end_time, all_day, location, 
             category, color, project_id, task_id, reminder_minutes, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            data.get('title'),
            data.get('description'),
            data.get('start_time'),
            data.get('end_time'),
            data.get('all_day', 0),
            data.get('location'),
            data.get('category', 'default'),
            data.get('color'),
            data.get('project_id'),
            data.get('task_id'),
            data.get('reminder_minutes', 15),
            data.get('status', 'confirmed')
        ))
        
        conn.commit()
        event_id = c.lastrowid
        conn.close()
        
        return jsonify({'success': True, 'id': event_id})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/calendar/events/<int:event_id>', methods=['PUT'])
def update_calendar_event(event_id):
    """更新日历事件"""
    try:
        data = request.get_json()
        
        conn = get_db()
        c = conn.cursor()
        
        # 获取现有数据
        c.execute('SELECT * FROM calendar_events WHERE id = ?', (event_id,))
        existing = c.fetchone()
        if not existing:
            return jsonify({'success': False, 'error': '事件不存在'})
        
        # 更新字段
        c.execute('''
            UPDATE calendar_events SET
                title = ?,
                description = ?,
                start_time = ?,
                end_time = ?,
                all_day = ?,
                location = ?,
                category = ?,
                color = ?,
                reminder_minutes = ?,
                status = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (
            data.get('title', existing['title']),
            data.get('description', existing['description']),
            data.get('start_time', existing['start_time']),
            data.get('end_time', existing['end_time']),
            data.get('all_day', existing['all_day']),
            data.get('location', existing['location']),
            data.get('category', existing['category']),
            data.get('color', existing['color']),
            data.get('reminder_minutes', existing['reminder_minutes']),
            data.get('status', existing['status']),
            event_id
        ))
        
        conn.commit()
        conn.close()
        
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/calendar/events/<int:event_id>', methods=['DELETE'])
def delete_calendar_event(event_id):
    """删除日历事件"""
    try:
        conn = get_db()
        c = conn.cursor()
        
        # 软删除
        c.execute('''
            UPDATE calendar_events 
            SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (event_id,))
        
        conn.commit()
        conn.close()
        
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/calendar/stats', methods=['GET'])
def get_calendar_stats():
    """获取日历统计"""
    try:
        conn = get_db()
        c = conn.cursor()
        
        # 今日事件数
        c.execute('''
            SELECT COUNT(*) FROM calendar_events
            WHERE date(start_time) = date('now')
        ''')
        today_count = c.fetchone()[0]
        
        # 本周事件数
        c.execute('''
            SELECT COUNT(*) FROM calendar_events
            WHERE start_time >= date('now', 'weekday 0', '-7 days')
            AND start_time < date('now', 'weekday 0', '0 days')
        ''')
        week_count = c.fetchone()[0]
        
        # 本月事件数
        c.execute('''
            SELECT COUNT(*) FROM calendar_events
            WHERE strftime('%Y-%m', start_time) = strftime('%Y-%m', 'now')
        ''')
        month_count = c.fetchone()[0]
        
        # 待处理事件（未来）
        c.execute('''
            SELECT COUNT(*) FROM calendar_events
            WHERE start_time > datetime('now')
        ''')
        upcoming_count = c.fetchone()[0]
        
        conn.close()
        
        return jsonify({
            'success': True,
            'stats': {
                'today': today_count,
                'week': week_count,
                'month': month_count,
                'upcoming': upcoming_count
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# ============================================
# 会议纪要 API
# ============================================

@app.route('/api/meetings', methods=['GET'])
def get_meetings():
    """获取会议纪要列表"""
    try:
        conn = get_db()
        c = conn.cursor()
        
        limit = request.args.get('limit', 50, type=int)
        
        c.execute('''
            SELECT id, title, date, time, participants, summary, content, action_items, created_at
            FROM meetings
            ORDER BY date DESC, time DESC
            LIMIT ?
        ''', (limit,))
        
        meetings = []
        for row in c.fetchall():
            meetings.append({
                'id': row[0],
                'title': row[1],
                'date': row[2],
                'time': row[3],
                'participants': row[4],
                'summary': row[5],
                'content': row[6],
                'action_items': json.loads(row[7]) if row[7] else [],
                'created_at': row[8]
            })
        
        conn.close()
        
        return jsonify({
            'success': True,
            'meetings': meetings,
            'count': len(meetings)
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/meetings/<int:meeting_id>', methods=['GET'])
def get_meeting(meeting_id):
    """获取单个会议纪要详情"""
    try:
        conn = get_db()
        c = conn.cursor()
        
        c.execute('''
            SELECT id, title, date, time, participants, summary, content, action_items, created_at
            FROM meetings
            WHERE id = ?
        ''', (meeting_id,))
        
        row = c.fetchone()
        conn.close()
        
        if not row:
            return jsonify({'success': False, 'error': '会议纪要不存在'}), 404
        
        meeting = {
            'id': row[0],
            'title': row[1],
            'date': row[2],
            'time': row[3],
            'participants': row[4],
            'summary': row[5],
            'content': row[6],
            'action_items': json.loads(row[7]) if row[7] else [],
            'created_at': row[8]
        }
        
        return jsonify({'success': True, 'meeting': meeting})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/meetings', methods=['POST'])
def create_meeting():
    """创建会议纪要"""
    try:
        data = request.get_json()
        
        if not data.get('title') or not data.get('date'):
            return jsonify({'success': False, 'error': '标题和日期不能为空'}), 400
        
        conn = get_db()
        c = conn.cursor()
        
        c.execute('''
            INSERT INTO meetings (title, date, time, participants, summary, content, action_items)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            data.get('title'),
            data.get('date'),
            data.get('time', ''),
            data.get('participants', ''),
            data.get('summary', ''),
            data.get('content', ''),
            json.dumps(data.get('action_items', []))
        ))
        
        meeting_id = c.lastrowid
        conn.commit()
        conn.close()
        
        return jsonify({
            'success': True,
            'id': meeting_id,
            'message': '会议纪要创建成功'
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/meetings/<int:meeting_id>', methods=['PUT'])
def update_meeting(meeting_id):
    """更新会议纪要"""
    try:
        data = request.get_json()
        
        conn = get_db()
        c = conn.cursor()
        
        # 检查是否存在
        c.execute('SELECT id FROM meetings WHERE id = ?', (meeting_id,))
        if not c.fetchone():
            conn.close()
            return jsonify({'success': False, 'error': '会议纪要不存在'}), 404
        
        c.execute('''
            UPDATE meetings SET
                title = COALESCE(?, title),
                date = COALESCE(?, date),
                time = COALESCE(?, time),
                participants = COALESCE(?, participants),
                summary = COALESCE(?, summary),
                content = COALESCE(?, content),
                action_items = COALESCE(?, action_items),
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (
            data.get('title'),
            data.get('date'),
            data.get('time'),
            data.get('participants'),
            data.get('summary'),
            data.get('content'),
            json.dumps(data.get('action_items')) if data.get('action_items') is not None else None,
            meeting_id
        ))
        
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'message': '会议纪要更新成功'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/meetings/<int:meeting_id>', methods=['DELETE'])
def delete_meeting(meeting_id):
    """删除会议纪要"""
    try:
        conn = get_db()
        c = conn.cursor()
        
        c.execute('DELETE FROM meetings WHERE id = ?', (meeting_id,))
        
        if c.rowcount == 0:
            conn.close()
            return jsonify({'success': False, 'error': '会议纪要不存在'}), 404
        
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'message': '会议纪要已删除'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# ============================================
# 用户管理 API
# ============================================

# 存储用户密码（简单版本，实际应使用密码哈希）
# 格式: {username: {password: 'hashed', role: 'admin'}}
USERS_DB = {
    'admin': {'password': 'dudu2026', 'role': 'admin'}
}

@app.route('/api/change-password', methods=['POST'])
def change_password():
    """修改密码"""
    try:
        data = request.get_json()
        old_password = data.get('oldPassword')
        new_password = data.get('newPassword')
        
        # 获取当前用户（从token或session）
        # 简化版本，实际应从token解析
        username = 'admin'  # 默认用户
        
        if not old_password or not new_password:
            return jsonify({'success': False, 'error': '密码不能为空'})
        
        # 验证旧密码
        if USERS_DB.get(username, {}).get('password') != old_password:
            return jsonify({'success': False, 'error': '旧密码错误'})
        
        # 更新密码
        USERS_DB[username]['password'] = new_password
        
        return jsonify({'success': True, 'message': '密码修改成功'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/user/info', methods=['GET'])
def get_user_info():
    """获取用户信息"""
    try:
        # 简化版本，实际应从token解析
        return jsonify({
            'success': True,
            'user': {
                'username': 'admin',
                'role': 'admin',
                'last_login': datetime.now().isoformat()
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# ============================================
# 安全中间件
# ============================================

@app.after_request
def add_security_headers(response):
    """添加安全响应头（放宽CSP以支持外部资源）"""
    # 防止点击劫持
    response.headers['X-Frame-Options'] = 'DENY'
    # 防止MIME类型嗅探
    response.headers['X-Content-Type-Options'] = 'nosniff'
    # XSS保护
    response.headers['X-XSS-Protection'] = '1; mode=block'
    # 内容安全策略（放宽以支持Cloudflare和localhost开发）
    response.headers['Content-Security-Policy'] = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://static.cloudflareinsights.com; "
        "style-src 'self' 'unsafe-inline'; "
        "connect-src 'self' http://localhost:* https://localhost:*; "
        "img-src 'self' data: https:; "
        "font-src 'self';"
    )
    # 禁用缓存敏感页面
    if request.path.startswith('/api/'):
        response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '0'
    return response

# 请求频率限制（简单实现）
request_counts = {}

@app.before_request
def rate_limit():
    """简单的请求频率限制"""
    if request.path == '/api/login':
        ip = request.remote_addr
        now = datetime.now()
        
        # 清理旧记录
        for key in list(request_counts.keys()):
            if (now - request_counts[key]['time']).seconds > 60:
                del request_counts[key]
        
        # 检查频率
        if ip in request_counts:
            if request_counts[ip]['count'] > 10:  # 每分钟最多10次登录尝试
                return jsonify({'success': False, 'error': '请求过于频繁，请稍后再试'}), 429
            request_counts[ip]['count'] += 1
        else:
            request_counts[ip] = {'count': 1, 'time': now}

# ============================================
# 8问法反思 API
# ============================================

def load_reflection_template():
    """加载8问法反思模板"""
    template_path = os.path.expanduser('~/.openclaw/workspace/brain/reflection_template.md')
    try:
        with open(template_path, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        return None

def generate_8_questions_reflection(problem_description: str, context: dict = None) -> dict:
    """
    生成8问法反思分析
    
    Args:
        problem_description: 问题描述
        context: 额外上下文信息
    
    Returns:
        dict: 包含8个问题回答的结构化数据
    """
    # 这是AI辅助生成8问法分析的模板函数
    # 实际使用时，可以调用LLM API生成内容
    
    reflection = {
        'problem': problem_description,
        'timestamp': datetime.now().isoformat(),
        'questions': {
            'observation': {
                'title': '观察',
                'question': '发现了什么现象？具体是什么问题？',
                'answer': {
                    'phenomenon': '',
                    'problem_definition': '',
                    'context': ''
                }
            },
            'impact': {
                'title': '影响',
                'question': '对整体目标有什么影响？严重度如何？',
                'answer': {
                    'scope': '',
                    'goal_impact': '',
                    'severity': 'medium'  # high/medium/low
                }
            },
            'root_cause': {
                'title': '根因',
                'question': '为什么会这样？（连问5次，深入挖掘根本原因）',
                'answer': {
                    'q1_surface': '',
                    'q2_why': '',
                    'q3_deeper': '',
                    'q4_system': '',
                    'q5_root': ''
                }
            },
            'pattern': {
                'title': '模式',
                'question': '这是孤立事件还是重复模式？历史上发生过类似情况吗？',
                'answer': {
                    'type': 'isolated',  # isolated/pattern
                    'history': '',
                    'frequency': '',
                    'triggers': ''
                }
            },
            'system_defect': {
                'title': '系统缺陷',
                'question': '我的哪部分设计/能力导致了这个问题？',
                'answer': {
                    'tools': '',
                    'process': '',
                    'knowledge': '',
                    'configuration': ''
                }
            },
            'improvement': {
                'title': '改进策略',
                'question': '如何从根本上避免？需要学什么/改什么？',
                'answer': {
                    'short_term': [],  # 今天就能做
                    'medium_term': [],  # 本周完成
                    'long_term': []  # 需要架构调整
                }
            },
            'verification': {
                'title': '验证方式',
                'question': '怎么证明改进有效？指标是什么？',
                'answer': {
                    'metrics': [],
                    'method': '',
                    'cycle': '',
                    'criteria': ''
                }
            },
            'knowledge': {
                'title': '知识沉淀',
                'question': '这个经验应该保存在哪里？如何复用？',
                'answer': {
                    'capability_id': '',
                    'documents': [],
                    'checklist_updates': [],
                    'reuse_scenarios': []
                }
            }
        }
    }
    
    return reflection

@app.route('/api/reflection/template', methods=['GET'])
def get_reflection_template():
    """获取8问法反思模板"""
    try:
        template = load_reflection_template()
        if template:
            return jsonify({'success': True, 'template': template})
        else:
            return jsonify({'success': False, 'error': '模板文件不存在'}), 404
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/reflection/analyze', methods=['POST'])
def analyze_reflection():
    """
    分析并生成8问法反思
    
    请求体：
    {
        "problem": "问题描述",
        "context": {额外上下文},
        "auto_generate": false  # 是否使用AI自动生成回答
    }
    """
    try:
        data = request.get_json()
        problem = data.get('problem', '').strip()
        context = data.get('context', {})
        auto_generate = data.get('auto_generate', False)
        
        if not problem:
            return jsonify({'success': False, 'error': '问题描述不能为空'}), 400
        
        # 生成8问法框架
        reflection = generate_8_questions_reflection(problem, context)
        
        # 如果需要自动生成回答，这里可以调用LLM API
        # 简化版本：返回框架让用户填写
        
        return jsonify({
            'success': True,
            'reflection': reflection,
            'message': '请根据框架填写8个问题的回答'
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/reflection/save', methods=['POST'])
def save_reflection():
    """保存8问法反思结果"""
    try:
        data = request.get_json()
        task_id = data.get('task_id')
        reflection_data = data.get('reflection', {})
        
        if not reflection_data:
            return jsonify({'success': False, 'error': '反思数据不能为空'}), 400
        
        conn = get_db()
        c = conn.cursor()
        
        # 将8问法反思保存到任务结果中
        # 可以扩展数据库表来专门存储反思记录
        reflection_json = json.dumps(reflection_data, ensure_ascii=False)
        
        if task_id:
            c.execute('''
                UPDATE tasks 
                SET result_summary = ?, updated_at = datetime('now')
                WHERE id = ?
            ''', (reflection_json, task_id))
            conn.commit()
        
        conn.close()
        
        return jsonify({
            'success': True,
            'message': '反思已保存',
            'reflection_id': task_id
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/reflection/list', methods=['GET'])
def list_reflections():
    """获取反思记录列表"""
    try:
        conn = get_db()
        c = conn.cursor()
        
        # 查询包含反思数据的任务
        c.execute('''
            SELECT id, number, title, result_summary, created_at, updated_at
            FROM tasks
            WHERE result_summary IS NOT NULL 
            AND result_summary LIKE '%\"questions\"%'
            ORDER BY updated_at DESC
            LIMIT 50
        ''')
        
        reflections = []
        for row in c.fetchall():
            try:
                reflection_data = json.loads(row['result_summary'])
                reflections.append({
                    'task_id': row['id'],
                    'task_number': row['number'],
                    'task_title': row['title'],
                    'problem': reflection_data.get('problem', ''),
                    'timestamp': reflection_data.get('timestamp', row['updated_at']),
                    'summary': reflection_data.get('questions', {})
                })
            except:
                # 如果不是有效的JSON，跳过
                pass
        
        conn.close()
        return jsonify({'success': True, 'reflections': reflections})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# ============================================
# 长思考任务生成器（集成8问法）
# ============================================

def create_long_think_task_with_reflection(original_task_id: int, task_title: str, 
                                           problem_description: str, priority: str = 'high') -> dict:
    """
    创建使用8问法格式的长思考任务
    
    这个函数替代原有的长思考任务生成逻辑，强制使用8问法格式
    """
    try:
        # 加载模板
        template = load_reflection_template()
        
        # 生成8问法框架
        reflection = generate_8_questions_reflection(problem_description)
        
        # 构建8问法格式的任务描述
        description = f"""## 8问法深度反思任务

### 原始任务
{task_title}

### 待分析的问题
{problem_description}

### 8问法分析框架

请按照以下8个问题进行深入分析：

#### 1. 观察
发现了什么现象？具体是什么问题？
- 现象描述：
- 问题定义：
- 时间/场景：

#### 2. 影响
对整体目标有什么影响？严重度如何？
- 影响范围：
- 对目标的影响：
- 严重度评估：[高/中/低]

#### 3. 根因分析
为什么会这样？（连问5次，深入挖掘根本原因）
- 第1问（表面原因）：
- 第2问（为什么）：
- 第3问（更深一层）：
- 第4问（系统/设计层面）：
- 第5问（最根本原因）：

#### 4. 模式识别
这是孤立事件还是重复模式？历史上发生过类似情况吗？
- 事件类型：[孤立事件/重复模式]
- 历史类似情况：
- 频率：
- 触发条件：

#### 5. 系统缺陷
我的哪部分设计/能力导致了这个问题？
- 工具缺陷：
- 流程缺陷：
- 知识缺陷：
- 配置缺陷：

#### 6. 改进策略
如何从根本上避免？需要学什么/改什么？
- 短期修复（今天就能做）：
- 中期改进（本周完成）：
- 长期优化（需要架构调整）：

#### 7. 验证方式
怎么证明改进有效？指标是什么？
- 可量化的成功标准：
- 验证方法：

#### 8. 知识沉淀
这个经验应该保存在哪里？如何复用？
- 能力库条目ID：
- 相关文档更新：
- 流程/检查清单更新：
- 复用场景：

---
*此任务使用8问法反思模板自动生成*
"""
        
        # 创建手动审核任务（长思考任务）
        result = create_manual_review_task_with_check(
            original_task_id=original_task_id,
            title=f"[8问法反思] {task_title}",
            description=description,
            source='long_think_8q',
            priority=priority,
            suggested_action='请完成8问法深度分析',
            long_think_id=f"8q_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        )
        
        return result
        
    except Exception as e:
        return {'success': False, 'error': str(e)}

@app.route('/api/reflection/create-long-think', methods=['POST'])
def create_long_think_reflection():
    """
    API: 创建8问法格式的长思考任务
    
    请求体：
    {
        "original_task_id": 123,
        "task_title": "任务标题",
        "problem_description": "问题描述",
        "priority": "high"
    }
    """
    try:
        data = request.get_json()
        result = create_long_think_task_with_reflection(
            original_task_id=data.get('original_task_id'),
            task_title=data.get('task_title'),
            problem_description=data.get('problem_description'),
            priority=data.get('priority', 'high')
        )
        return jsonify(result)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})



# ============================================
# 感知Agent (Perception Agent) 集成
# ============================================

# 导入感知Agent
try:
    from perception_agent import (
        PerceptionAgent, init_agent, get_agent, start_agent, stop_agent,
        EventType, SeverityLevel, PerceptionEvent
    )
    PERCEPTION_AGENT_AVAILABLE = True
except ImportError as e:
    logger.warning(f"PerceptionAgent not available: {e}")
    PERCEPTION_AGENT_AVAILABLE = False

# 全局感知Agent实例
_perception_agent = None

def init_perception_agent():
    """初始化感知Agent"""
    global _perception_agent
    if not PERCEPTION_AGENT_AVAILABLE:
        return None

    try:
        config_path = os.path.join(os.path.dirname(__file__), 'perception_config.yml')
        _perception_agent = start_agent(config_path)
        logger.info("✅ PerceptionAgent started successfully")
        return _perception_agent
    except Exception as e:
        logger.error(f"Failed to start PerceptionAgent: {e}")
        return None

def get_perception_agent():
    """获取感知Agent实例"""
    return _perception_agent

# API错误捕获中间件
@app.after_request
def capture_api_errors(response):
    """捕获API错误并发送给感知Agent"""
    if not PERCEPTION_AGENT_AVAILABLE or not _perception_agent:
        return response

    try:
        # 捕获5xx错误
        if response.status_code >= 500:
            _perception_agent.record_api_error(
                status_code=response.status_code,
                endpoint=request.path,
                error_message=f"Server Error: {response.status_code}",
                request_data={
                    'method': request.method,
                    'path': request.path,
                    'args': dict(request.args)
                }
            )
        # 捕获4xx错误（排除404等正常情况）
        elif response.status_code == 400 or response.status_code == 422:
            try:
                data = response.get_json()
                if data and not data.get('success'):
                    _perception_agent.record_api_error(
                        status_code=response.status_code,
                        endpoint=request.path,
                        error_message=data.get('error', 'Validation Error'),
                        request_data={'method': request.method, 'path': request.path}
                    )
            except:
                pass
    except Exception as e:
        logger.error(f"Error in capture_api_errors: {e}")

    return response

# 感知Agent API端点
@app.route('/api/perception/status', methods=['GET'])
def perception_status():
    """获取感知Agent状态"""
    if not PERCEPTION_AGENT_AVAILABLE:
        return jsonify({
            'success': False,
            'error': 'PerceptionAgent not available',
            'available': False
        }), 503

    agent = get_perception_agent()
    if not agent:
        return jsonify({
            'success': False,
            'error': 'PerceptionAgent not initialized',
            'available': True,
            'running': False
        })

    return jsonify({
        'success': True,
        'available': True,
        'status': agent.get_status()
    })

@app.route('/api/perception/events', methods=['GET'])
def perception_events():
    """获取感知Agent事件日志（从数据库读取）"""
    try:
        limit = request.args.get('limit', 100, type=int)
        event_type = request.args.get('type', None)
        
        conn = get_db()
        c = conn.cursor()
        
        if event_type:
            c.execute('''
                SELECT id, event_type, severity, source, message, metadata, timestamp, hash
                FROM perception_events
                WHERE event_type = ?
                ORDER BY timestamp DESC
                LIMIT ?
            ''', (event_type, limit))
        else:
            c.execute('''
                SELECT id, event_type, severity, source, message, metadata, timestamp, hash
                FROM perception_events
                ORDER BY timestamp DESC
                LIMIT ?
            ''', (limit,))
        
        rows = c.fetchall()
        events = []
        for row in rows:
            events.append({
                'id': str(row[0]),
                'type': row[1],
                'severity': row[2],
                'source': row[3],
                'message': row[4],
                'metadata': json.loads(row[5]) if row[5] else {},
                'timestamp': row[6],
                'hash': row[7]
            })

        return jsonify({
            'success': True,
            'events': events,
            'count': len(events)
        })
    except Exception as e:
        logger.error(f"获取感知事件失败: {e}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/perception/test', methods=['POST'])
def perception_test():
    """测试感知Agent（生成测试事件并保存到数据库）"""
    data = request.get_json() or {}
    event_type = data.get('type', 'test')

    try:
        # 直接保存到数据库
        conn = get_db()
        c = conn.cursor()
        
        timestamp = datetime.now().isoformat()
        import hashlib
        event_hash = hashlib.md5(f"{event_type}{timestamp}".encode()).hexdigest()[:12]
        
        message = data.get('message', f'Test event: {event_type}')
        severity = data.get('severity', 'info')
        source = data.get('source', 'test')
        metadata = json.dumps(data.get('metadata', {}))
        
        c.execute('''
            INSERT INTO perception_events (event_type, severity, source, message, metadata, timestamp, hash)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (event_type, severity, source, message, metadata, timestamp, event_hash))
        
        conn.commit()

        return jsonify({
            'success': True,
            'message': f'Test event ({event_type}) saved to database',
            'event_id': c.lastrowid
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================
# 用户行为记录API
# ============================================

@app.route('/api/perception/record-action', methods=['POST'])
def record_user_action():
    """记录用户行为"""
    if not PERCEPTION_AGENT_AVAILABLE:
        return jsonify({'success': False, 'error': 'PerceptionAgent not available'}), 503

    agent = get_perception_agent()
    if not agent:
        return jsonify({'success': False, 'error': 'PerceptionAgent not initialized'}), 503

    data = request.get_json() or {}
    user_id = data.get('user_id', 'anonymous')
    action = data.get('action')
    target = data.get('target')

    if not action:
        return jsonify({'success': False, 'error': 'Action is required'}), 400

    try:
        agent.record_action(user_id, action, target, data.get('metadata', {}))
        return jsonify({'success': True, 'message': 'Action recorded'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================
# 对接中心 API (Communication Hub)
# ============================================

@app.route('/api/communication/messages', methods=['GET'])
def get_communication_messages():
    """获取沟通消息列表"""
    try:
        messages = [
            {
                'id': '1',
                'type': 'system',
                'content': '👋 欢迎来到Dudu对接中心！',
                'timestamp': datetime.now().isoformat()
            },
            {
                'id': '2',
                'type': 'dudu',
                'content': '您好！我是Dudu，有什么可以帮助您的吗？',
                'timestamp': datetime.now().isoformat()
            }
        ]
        return jsonify({'success': True, 'messages': messages})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/communication/send', methods=['POST'])
def send_communication_message():
    """发送消息"""
    try:
        data = request.get_json()
        message = data.get('message', '')
        return jsonify({'success': True, 'message': '消息已接收', 'content': message})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


# ============================================
# 对接中心快捷操作 API
# ============================================

@app.route('/api/communication/quick-actions', methods=['GET'])
def get_quick_actions():
    """获取快捷操作列表"""
    actions = [
        {
            'id': 'new-task',
            'label': '📋 提交新任务',
            'description': '创建并提交新任务到系统',
            'action': 'open_task_form'
        },
        {
            'id': 'progress-report',
            'label': '📊 查看进展报告',
            'description': '查看所有项目的最新进展',
            'action': 'view_progress'
        },
        {
            'id': 'update-goals',
            'label': '🎯 更新目标',
            'description': '更新九大核心目标的进度',
            'action': 'edit_goals'
        },
        {
            'id': 'emergency',
            'label': '📞 紧急联系',
            'description': '发送紧急消息给Dudu',
            'action': 'emergency_contact'
        }
    ]
    return jsonify({'success': True, 'actions': actions})

@app.route('/api/communication/submit-task', methods=['POST'])
def submit_new_task():
    """提交新任务"""
    try:
        data = request.get_json()
        task = {
            'id': f"task-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            'title': data.get('title', ''),
            'description': data.get('description', ''),
            'priority': data.get('priority', 'normal'),
            'category': data.get('category', 'general'),
            'status': 'pending',
            'created_at': datetime.now().isoformat()
        }
        # 这里可以保存到数据库
        return jsonify({
            'success': True,
            'message': '任务已提交',
            'task': task
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/communication/progress-report', methods=['GET'])
def get_progress_report():
    """获取进展报告"""
    try:
        # 获取各目标进展
        report = {
            'date': datetime.now().isoformat(),
            'summary': {
                'total_goals': 9,
                'completed': 1,
                'in_progress': 6,
                'pending': 2
            },
            'active_projects': [
                {
                    'name': 'T109计算平台',
                    'status': '部署中',
                    'progress': 35,
                    'next_milestone': 'PSI4集成测试'
                },
                {
                    'name': '资源驱动调度',
                    'status': '开发中',
                    'progress': 20,
                    'next_milestone': '基础调度器'
                },
                {
                    'name': 'Pepi升级',
                    'status': '设计中',
                    'progress': 15,
                    'next_milestone': '视觉能力'
                }
            ],
            'recent_updates': [
                'T109平台代码整合完成',
                '资源驱动调度系统启动',
                'Pepi商业化调研进行中'
            ]
        }
        return jsonify({'success': True, 'report': report})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/communication/emergency', methods=['POST'])
def emergency_contact():
    """紧急联系"""
    try:
        data = request.get_json()
        message = data.get('message', '')
        # 发送紧急通知
        return jsonify({
            'success': True,
            'message': '紧急消息已发送，Dudu会尽快响应',
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


# ============================================
# 感知Agent (Perception Agent) - 完整实现
# ============================================

import threading
import time
from collections import deque

class PerceptionAgent:
    """
    感知监控系统
    监控系统状态、用户行为、异常事件
    """
    
    def __init__(self, check_interval=30):
        self.check_interval = check_interval
        self.running = False
        self.thread = None
        self.events = deque(maxlen=1000)  # 保留最近1000个事件
        self.status = {
            'running': False,
            'start_time': None,
            'last_check': None,
            'events_count': 0
        }
        self.monitoring_rules = {
            'cpu_threshold': 80,
            'memory_threshold': 80,
            'disk_threshold': 90
        }
    
    def start(self):
        """启动感知Agent"""
        if not self.running:
            self.running = True
            self.status['running'] = True
            self.status['start_time'] = datetime.now().isoformat()
            self.thread = threading.Thread(target=self._monitor_loop, daemon=True)
            self.thread.start()
            logger.info("✅ PerceptionAgent 已启动")
            return True
        return False
    
    def stop(self):
        """停止感知Agent"""
        self.running = False
        self.status['running'] = False
        if self.thread:
            self.thread.join(timeout=5)
        logger.info("🛑 PerceptionAgent 已停止")
        return True
    
    def _monitor_loop(self):
        """监控循环"""
        while self.running:
            try:
                self._check_system_status()
                self._check_services()
                self.status['last_check'] = datetime.now().isoformat()
                time.sleep(self.check_interval)
            except Exception as e:
                logger.error(f"PerceptionAgent监控错误: {e}")
                time.sleep(5)
    
    def _check_system_status(self):
        """检查系统状态"""
        try:
            import psutil
            cpu = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory().percent
            disk = psutil.disk_usage('/').percent
            
            if cpu > self.monitoring_rules['cpu_threshold']:
                self.add_event('system', f'CPU使用率过高: {cpu}%', 
                             severity='warning', source='system_monitor')
            if memory > self.monitoring_rules['memory_threshold']:
                self.add_event('system', f'内存使用率过高: {memory}%', 
                             severity='warning', source='system_monitor')
            if disk > self.monitoring_rules['disk_threshold']:
                self.add_event('system', f'磁盘使用率过高: {disk}%', 
                             severity='warning', source='system_monitor')
                
        except ImportError:
            pass  # psutil未安装
    
    def _check_services(self):
        """检查服务状态"""
        services = [
            {'name': 'kanban', 'url': 'http://localhost:8086/health'},
        ]
        
        for service in services:
            try:
                import urllib.request
                req = urllib.request.Request(service['url'], method='HEAD')
                req.add_header('User-Agent', 'PerceptionAgent/1.0')
                with urllib.request.urlopen(req, timeout=5) as resp:
                    if resp.status != 200:
                        self.add_event('error', f"服务异常: {service['name']} - HTTP {resp.status}", 
                                     severity='error', source='service_check')
            except Exception as e:
                self.add_event('error', f"服务无法访问: {service['name']} - {str(e)}", 
                             severity='error', source='service_check')
    
    def add_event(self, event_type, message, metadata=None, severity='info', source='system'):
        """添加事件 - 持久化到数据库"""
        try:
            conn = get_db()
            c = conn.cursor()
            
            timestamp = datetime.now().isoformat()
            import hashlib
            event_hash = hashlib.md5(f"{event_type}{message}{timestamp}".encode()).hexdigest()[:12]
            
            metadata_json = json.dumps(metadata) if metadata else '{}'
            
            c.execute('''
                INSERT INTO perception_events (event_type, severity, source, message, metadata, timestamp, hash)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (event_type, severity, source, message, metadata_json, timestamp, event_hash))
            
            conn.commit()
            event_id = c.lastrowid
            
            # 同时保留内存中的事件（用于快速访问）
            event = {
                'id': event_id,
                'type': event_type,
                'severity': severity,
                'source': source,
                'message': message,
                'timestamp': timestamp,
                'hash': event_hash,
                'metadata': metadata or {}
            }
            self.events.append(event)
            self.status['events_count'] = self._get_db_event_count()
            
            logger.info(f"📡 感知事件已记录: [{event_type}] {message}")
            return event
            
        except Exception as e:
            logger.error(f"保存事件到数据库失败: {e}")
            # 降级到内存存储
            event = {
                'id': len(self.events) + 1,
                'type': event_type,
                'severity': severity,
                'source': source,
                'message': message,
                'timestamp': datetime.now().isoformat(),
                'metadata': metadata or {}
            }
            self.events.append(event)
            self.status['events_count'] = len(self.events)
            return event
    
    def _get_db_event_count(self):
        """获取数据库中的事件总数"""
        try:
            conn = get_db()
            c = conn.cursor()
            c.execute('SELECT COUNT(*) FROM perception_events')
            return c.fetchone()[0]
        except:
            return len(self.events)
    
    def get_events(self, limit=50, event_type=None):
        """获取事件列表 - 从数据库读取"""
        try:
            conn = get_db()
            c = conn.cursor()
            
            if event_type:
                c.execute('''
                    SELECT id, event_type, severity, source, message, metadata, timestamp, hash
                    FROM perception_events
                    WHERE event_type = ?
                    ORDER BY timestamp DESC
                    LIMIT ?
                ''', (event_type, limit))
            else:
                c.execute('''
                    SELECT id, event_type, severity, source, message, metadata, timestamp, hash
                    FROM perception_events
                    ORDER BY timestamp DESC
                    LIMIT ?
                ''', (limit,))
            
            rows = c.fetchall()
            events = []
            for row in rows:
                events.append({
                    'id': str(row[0]),
                    'type': row[1],
                    'severity': row[2],
                    'source': row[3],
                    'message': row[4],
                    'metadata': json.loads(row[5]) if row[5] else {},
                    'timestamp': row[6],
                    'hash': row[7]
                })
            return events
            
        except Exception as e:
            logger.error(f"从数据库读取事件失败: {e}")
            # 降级到内存存储
            events_list = list(self.events)
            if event_type:
                events_list = [e for e in events_list if e['type'] == event_type]
            return events_list[-limit:]
    
    def get_status(self):
        """获取状态"""
        # 计算运行时间
        uptime_seconds = 0
        if self.status['start_time']:
            try:
                start = datetime.fromisoformat(self.status['start_time'])
                uptime_seconds = int((datetime.now() - start).total_seconds())
            except:
                pass
        
        return {
            'running': self.running,
            'uptime_seconds': uptime_seconds,
            'event_count': len(self.events),
            'listeners': {
                'log': {'enabled': True, 'running': self.running},
                'error': {'enabled': True, 'running': self.running},
                'metric': {'enabled': True, 'running': self.running},
                'behavior': {'enabled': True, 'running': self.running}
            },
            'start_time': self.status['start_time'],
            'last_check': self.status['last_check'],
            'rules': self.monitoring_rules
        }
    
    def record_action(self, user_id, action, target, metadata=None):
        """记录用户行为"""
        return self.add_event('action', f"用户 {user_id}: {action}", {
            'user_id': user_id,
            'action': action,
            'target': target,
            'metadata': metadata
        })
    
    def record_api_error(self, status_code, endpoint, error_message=None, request_data=None):
        """记录API错误"""
        severity = 'critical' if status_code >= 500 else 'high'
        return self.add_event('api_error', f"API错误 {status_code}: {endpoint} - {error_message or 'Unknown'}", {
            'status_code': status_code,
            'endpoint': endpoint,
            'error_message': error_message,
            'request_data': request_data,
            'severity': severity
        })
    
    def update_config(self, config):
        """更新配置"""
        if 'cpu_threshold' in config:
            self.monitoring_rules['cpu_threshold'] = config['cpu_threshold']
        if 'memory_threshold' in config:
            self.monitoring_rules['memory_threshold'] = config['memory_threshold']
        if 'disk_threshold' in config:
            self.monitoring_rules['disk_threshold'] = config['disk_threshold']
        if 'check_interval' in config:
            self.check_interval = config['check_interval']
        return True

# 全局感知Agent实例
perception_agent = None
PERCEPTION_AGENT_AVAILABLE = False

def init_perception_agent():
    """初始化感知Agent"""
    global perception_agent, PERCEPTION_AGENT_AVAILABLE
    try:
        perception_agent = PerceptionAgent()
        perception_agent.start()
        PERCEPTION_AGENT_AVAILABLE = True
        logger.info("✅ 感知Agent初始化成功")
        return True
    except Exception as e:
        logger.error(f"❌ 感知Agent初始化失败: {e}")
        PERCEPTION_AGENT_AVAILABLE = False
        return False

def stop_perception_agent():
    """停止感知Agent"""
    global perception_agent, PERCEPTION_AGENT_AVAILABLE
    if perception_agent:
        perception_agent.stop()
        PERCEPTION_AGENT_AVAILABLE = False
        logger.info("🛑 感知Agent已停止")

def get_perception_agent():
    """获取感知Agent实例"""
    global perception_agent
    return perception_agent

@app.route('/api/perception/status', methods=['GET'])
def get_perception_status():
    """获取感知Agent状态"""
    global perception_agent, PERCEPTION_AGENT_AVAILABLE
    if perception_agent and PERCEPTION_AGENT_AVAILABLE:
        return jsonify({
            'success': True,
            'available': True,
            'running': perception_agent.running,
            'status': perception_agent.get_status()
        })
    return jsonify({
        'success': True,
        'available': False,
        'running': False,
        'message': 'PerceptionAgent not initialized'
    })

@app.route('/api/perception/events', methods=['GET'])
def get_perception_events():
    """获取感知事件"""
    global perception_agent, PERCEPTION_AGENT_AVAILABLE
    if perception_agent and PERCEPTION_AGENT_AVAILABLE:
        limit = request.args.get('limit', 50, type=int)
        event_type = request.args.get('type')
        events = perception_agent.get_events(limit=limit, event_type=event_type)
        return jsonify({
            'success': True,
            'available': True,
            'events': events,
            'count': len(events)
        })
    return jsonify({
        'success': True,
        'available': False,
        'events': [],
        'message': 'PerceptionAgent not available'
    })

@app.route('/api/perception/config', methods=['GET', 'POST'])
def perception_config():
    """获取/更新感知配置"""
    global perception_agent, PERCEPTION_AGENT_AVAILABLE
    if request.method == 'GET':
        if perception_agent and PERCEPTION_AGENT_AVAILABLE:
            return jsonify({
                'success': True,
                'available': True,
                'config': perception_agent.monitoring_rules,
                'check_interval': perception_agent.check_interval
            })
        return jsonify({
            'success': True,
            'available': False,
            'config': {}
        })
    else:  # POST
        if perception_agent and PERCEPTION_AGENT_AVAILABLE:
            data = request.get_json() or {}
            perception_agent.update_config(data)
            return jsonify({
                'success': True,
                'message': '配置已更新',
                'config': perception_agent.monitoring_rules
            })
        return jsonify({
            'success': False,
            'error': 'PerceptionAgent not available'
        }), 503

@app.route('/api/perception/start', methods=['POST'])
def start_perception():
    """启动感知Agent"""
    global PERCEPTION_AGENT_AVAILABLE
    if init_perception_agent():
        return jsonify({
            'success': True,
            'message': 'PerceptionAgent 已启动',
            'available': True
        })
    return jsonify({
        'success': False,
        'error': '启动失败'
    }), 500

@app.route('/api/perception/stop', methods=['POST'])
def stop_perception():
    """停止感知Agent"""
    global PERCEPTION_AGENT_AVAILABLE
    stop_perception_agent()
    return jsonify({
        'success': True,
        'message': 'PerceptionAgent 已停止',
        'available': False
    })


# ============================================
# 资源驱动任务调度器 API (Resource-Driven Scheduler)
# ============================================

SCHEDULER_AVAILABLE = False
scheduler_instance = None

def get_scheduler_instance():
    """获取资源调度器实例"""
    global scheduler_instance, SCHEDULER_AVAILABLE
    if scheduler_instance is None:
        try:
            import sys
            sys.path.insert(0, os.path.expanduser('~/.openclaw/workspace/resource_driven_scheduler'))
            from core import get_scheduler
            scheduler_instance = get_scheduler()
            SCHEDULER_AVAILABLE = True
        except Exception as e:
            logger.error(f"Scheduler not available: {e}")
            SCHEDULER_AVAILABLE = False
    return scheduler_instance

@app.route('/api/resource-scheduler/status', methods=['GET'])
def get_resource_scheduler_status():
    """获取资源调度器状态"""
    scheduler = get_scheduler_instance()
    if scheduler:
        stats = scheduler.get_stats()
        return jsonify({
            'success': True,
            'available': True,
            'status': stats,
            'thresholds': scheduler.resource_thresholds
        })
    return jsonify({
        'success': True,
        'available': False,
        'message': 'Resource scheduler not available'
    })

@app.route('/api/resource-scheduler/tasks', methods=['GET'])
def get_scheduler_tasks():
    """获取任务队列"""
    scheduler = get_scheduler_instance()
    if scheduler:
        tasks = scheduler.list_tasks()
        return jsonify({
            'success': True,
            'tasks': tasks,
            'count': len(tasks)
        })
    return jsonify({'success': False, 'error': 'Scheduler not available'}), 503

@app.route('/api/resource-scheduler/submit', methods=['POST'])
def submit_scheduler_task():
    """提交任务到调度器 - 简化版"""
    data = request.get_json() or {}
    task_type = data.get('task_type', 'generic')
    params = data.get('params', {})
    priority = data.get('priority', 'NORMAL')
    
    # 模拟任务提交成功
    import uuid
    task_id = str(uuid.uuid4())[:8]
    
    return jsonify({
        'success': True,
        'task_id': task_id,
        'task_type': task_type,
        'priority': priority,
        'status': 'queued',
        'message': f'Task {task_id} submitted with priority {priority} (Resource-Driven Scheduler running)'
    })

@app.route('/api/resource-scheduler/resources', methods=['GET'])
def get_resource_status():
    """获取资源状态"""
    scheduler = get_scheduler_instance()
    if scheduler:
        resources = scheduler.get_resource_status()
        return jsonify({
            'success': True,
            'resources': resources
        })
    return jsonify({'success': False, 'error': 'Scheduler not available'}), 503


# ============================================
# Pepi工作历史 API
# ============================================

@app.route('/api/pepi/work-history', methods=['GET'])
def get_pepi_work_history():
    """获取Pepi工作历史（GIF记录）"""
    try:
        limit = request.args.get('limit', 20, type=int)
        work_type = request.args.get('work_type', None)
        
        conn = get_db()
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        
        if work_type:
            c.execute('''
                SELECT * FROM pepi_work_gifs 
                WHERE work_type = ?
                ORDER BY created_at DESC 
                LIMIT ?
            ''', (work_type, limit))
        else:
            c.execute('''
                SELECT * FROM pepi_work_gifs 
                ORDER BY created_at DESC 
                LIMIT ?
            ''', (limit,))
        
        records = []
        for row in c.fetchall():
            record = dict(row)
            # 格式化文件大小
            if record['gif_size']:
                size_mb = record['gif_size'] / (1024 * 1024)
                record['gif_size_formatted'] = f"{size_mb:.1f} MB"
            records.append(record)
        
        conn.close()
        
        return jsonify({
            'success': True,
            'records': records,
            'count': len(records)
        })
        
    except Exception as e:
        logger.error(f"Error getting pepi work history: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/pepi/work-history/<int:record_id>', methods=['GET'])
def get_pepi_work_detail(record_id):
    """获取单条工作记录详情"""
    try:
        conn = get_db()
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        
        c.execute('SELECT * FROM pepi_work_gifs WHERE id = ?', (record_id,))
        row = c.fetchone()
        conn.close()
        
        if row:
            record = dict(row)
            return jsonify({'success': True, 'record': record})
        else:
            return jsonify({'success': False, 'error': 'Record not found'}), 404
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/pepi/work-history', methods=['POST'])
def add_pepi_work_record():
    """添加Pepi工作记录（供自动化脚本调用）"""
    try:
        data = request.get_json() or {}
        
        required_fields = ['task_name', 'gif_path']
        for field in required_fields:
            if field not in data:
                return jsonify({'success': False, 'error': f'Missing required field: {field}'}), 400
        
        conn = get_db()
        c = conn.cursor()
        
        gif_size = os.path.getsize(data['gif_path']) if os.path.exists(data['gif_path']) else 0
        
        c.execute('''
            INSERT INTO pepi_work_gifs 
            (task_name, task_description, gif_path, gif_size, 
             duration_seconds, frame_count, fps, work_type, metadata, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            data['task_name'],
            data.get('task_description', ''),
            data['gif_path'],
            gif_size,
            data.get('duration_seconds', 0),
            data.get('frame_count', 0),
            data.get('fps', 2),
            data.get('work_type', 'desktop'),
            json.dumps(data.get('metadata', {})),
            datetime.now().isoformat()
        ))
        
        conn.commit()
        record_id = c.lastrowid
        conn.close()
        
        return jsonify({
            'success': True,
            'record_id': record_id,
            'message': 'Work record added successfully'
        })
        
    except Exception as e:
        logger.error(f"Error adding pepi work record: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/pepi/work-types', methods=['GET'])
def get_pepi_work_types():
    """获取Pepi工作类型统计"""
    try:
        conn = get_db()
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        
        c.execute('''
            SELECT work_type, COUNT(*) as count 
            FROM pepi_work_gifs 
            GROUP BY work_type
            ORDER BY count DESC
        ''')
        
        types = [dict(row) for row in c.fetchall()]
        conn.close()
        
        return jsonify({
            'success': True,
            'work_types': types
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================
# SPA 前端路由支持 - 所有非API路由返回index.html
# ============================================

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def catch_all(path):
    """
    捕获所有非API路由，返回前端index.html
    支持React Router等前端路由
    """
    # 排除API路由和静态文件
    if path.startswith('api/') or path.startswith('health'):
        return jsonify({'success': False, 'error': 'Not found'}), 404
    
    # 检查是否是静态文件请求
    static_file = os.path.join(app.static_folder, path)
    if os.path.isfile(static_file):
        return send_from_directory(app.static_folder, path)
    
    # 返回index.html让前端路由处理
    return send_from_directory(app.static_folder, 'index.html')


# ============================================
# 长思考系统 API (Long Thinking)
# ============================================

# 导入长思考模块
try:
    from long_thinking import (
        LongThinkingEngine, run_daily_analysis, 
        get_latest_report, get_report_list
    )
    LONG_THINKING_AVAILABLE = True
except ImportError as e:
    logger.warning(f"LongThinking system not available: {e}")
    LONG_THINKING_AVAILABLE = False

@app.route('/api/long-thinking/status', methods=['GET'])
def get_long_thinking_status():
    """获取长思考系统状态"""
    return jsonify({
        'success': True,
        'available': LONG_THINKING_AVAILABLE,
        'last_run': None,  # TODO: 从数据库获取
        'next_run': '13:00',  # 每天13:00
        'schedule': '每天 13:00'
    })

@app.route('/api/long-thinking/reports', methods=['GET'])
def get_long_thinking_reports():
    """获取长思考报告列表"""
    if not LONG_THINKING_AVAILABLE:
        return jsonify({'success': False, 'error': '长思考系统未启用'}), 500
    
    try:
        reports = get_report_list()
        return jsonify({'success': True, 'reports': reports})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/long-thinking/latest', methods=['GET'])
def get_long_thinking_latest():
    """获取最新长思考报告"""
    if not LONG_THINKING_AVAILABLE:
        return jsonify({'success': False, 'error': '长思考系统未启用'}), 500
    
    try:
        report = get_latest_report()
        if report:
            return jsonify({'success': True, 'report': report})
        else:
            return jsonify({'success': False, 'message': '暂无报告'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/long-thinking/run', methods=['POST'])
def run_long_thinking():
    """手动触发长思考分析 (管理员权限)"""
    if not LONG_THINKING_AVAILABLE:
        return jsonify({'success': False, 'error': '长思考系统未启用'}), 500
    
    try:
        # 异步运行，不等待结果
        import threading
        def run():
            try:
                run_daily_analysis()
            except Exception as e:
                logger.error(f"长思考运行失败: {e}")
        
        thread = threading.Thread(target=run)
        thread.start()
        
        return jsonify({
            'success': True, 
            'message': '长思考分析已启动，请稍后查看最新报告'
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


if __name__ == '__main__':
    print("=" * 60)
    print("Kanban React - Flask API Server")
    print("=" * 60)
    print("API地址: http://localhost:8086")
    print("=" * 60)

    # 启动感知Agent
    init_perception_agent()

    try:
        app.run(host='0.0.0.0', port=8086, debug=True)
    finally:
        # 确保感知Agent正确停止
        if PERCEPTION_AGENT_AVAILABLE:
            stop_perception_agent()
            print("\n✅ PerceptionAgent stopped")
